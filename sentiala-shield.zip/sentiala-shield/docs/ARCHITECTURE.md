# Sentiala Shield — Architecture

## System overview

Sentiala Shield is a modular, defensive-only security platform. The long-term
architecture installs once and protects everywhere:

```text
┌───────────────┐     native messaging      ┌────────────────────┐
│ Chrome / Edge │◄─────────────────────────►│  Sentiala Agent    │
│ Firefox       │  (extension <-> agent)     │  (Windows first;   │
└───────┬───────┘                            │  Linux/macOS later)│
        │ on-page indicator,                └─────────┬──────────┘
        │ right-click "Scan with Sentiala"             │ localhost (auth)
        ▼                                             ▼
┌──────────────────────┐   ┌─────────────────────────────────────┐
│  Sentiala Dashboard  │   │   SENTIALA INTELLIGENCE CORE         │
│  (command center)    │──►│   services/core/sentiala_core        │
└──────────────────────┘   │                                     │
                           │  orchestrator                       │
                           │    ├── url_analyzer   (Layer 1)     │
                           │    ├── providers/*    (Layer 2)    │
                           │    │     base.py — Provider ABC     │
                           │    │     urlhaus.py  rdap.py  doh.py│
                           │    │     [keyed adapters: Phase 4] │
                           │    ├── ai.py          (Layer 4)    │
                           │    │     AIProvider + LocalCorrel. │
                           │    ├── risk_engine    (Layer 5)    │
                           │    └── report         (Layer 6)     │
                           │                                     │
                           │  cache.py (TTL)  history.py (JSONL) │
                           └─────────────────────────────────────┘
                                        │ hostnames only
                                        ▼
                           ┌─────────────────────────────────────┐
                           │   SGIN — public intelligence sources │
                           │   URLhaus · RDAP · DoH · (Phase 4+:  │
                           │   Safe Browsing, PhishTank, …)      │
                           └─────────────────────────────────────┘
```

## The scan pipeline (implemented in this repository)

```text
USER INPUT  "sentiala scan <target>"
     │
     ▼
classify_target()          url | domain | ip | sha256/md5/sha1 | unknown
     │
     ▼
Layer 1  analyze_url()     deterministic, offline, reproducible:
     │                     scheme, userinfo, IP hosts, IDN homographs,
     │                     typosquatting (edit distance), brand-in-subdomain,
     │                     TLD reputation, shorteners, keywords, structure
     ▼
Layer 2  Provider.query() for each adapter (skipped in --offline):
     │                     URLhaus host lookup, RDAP registration data,
     │                     DoH resolution. TTL-cached. Failures degrade.
     ▼
Layer 5  assess()          weighted sum with impersonation-family
     │                     suppression; verdict bands; confidence from
     │                     evidence quality (offline ⇒ lower confidence)
     ▼
Layer 4  AIProvider.explain()   LocalCorrelator (deterministic) restates
     │                     only existing findings; cloud LLM in Phase 3
     ▼
Layer 6  build_report()   JSON + Markdown; four evidence classes;
     │                     sources with tiers; false-positive factors;
     │                     recommended action; disclaimer
     ▼
history.append()          local JSONL; future dashboard reads this
```

## Key design decisions

1. **No LLM verdicts.** The risk engine is deterministic and auditable. The AI layer explains; it never decides. (Spec §5.)
2. **Providers are adapters.** `Provider` ABC + registry; injectable HTTP sessions for testability; graceful degradation when a source fails; one source being down never produces a false "all clear" — it produces a recorded degradation. (Spec §41.)
3. **Privacy by construction.** Providers receive hostnames only. Cache keys are hostnames. History stores targets and verdicts, never page content. (Spec §28, §45.)
4. **Anti-fabrication as code.** `public_intelligence` can only be one of: findings that exist, `NO RELEVANT PUBLIC INTELLIGENCE FOUND`, or `UNVERIFIED — live intelligence unavailable`. Tests assert all three paths. (Spec §21.)
5. **Family suppression.** Homograph / typosquat / brand-in-subdomain all describe "this domain impersonates a brand"; only the strongest counts, so one suspicion can't be triple-counted into CRITICAL.
6. **Confidence ≠ severity.** Confidence measures how well-corroborated the assessment is (verified facts, distinct checks, live intel, mitigations). A SAFE verdict with no corroboration is low-confidence by design.

## Data flow privacy guarantees

| Data | Ever sent externally? | Stored locally? |
|---|---|---|
| Hostname of scanned target | yes — to intelligence providers, hostnames only | yes (history, cache) |
| Full URL | no (path/query stay local) | no |
| Page content, downloads | no | no |
| Credentials, cookies, tokens, keys | never collected | never |

## Extension / agent / dashboard (Phase 7–9 targets)

- **Browser extension** (`apps/browser-extension/`): content-script indicator, right-click "Scan with Sentiala Shield", warning interstitials. Speaks to the local agent over native messaging. **Never contains API keys** — all intelligence flows through the core.
- **Desktop agent** (`apps/desktop-agent/`): Windows-first tray agent hosting the core, exposing an authenticated localhost API for the extension and dashboard, managing notifications and threat history.
- **Dashboard** (`apps/dashboard/`): local web UI reading the same JSONL history and report store — the future command center.

Each is scaffolded with a README describing its contract; they are deliberately not fake-implemented.
