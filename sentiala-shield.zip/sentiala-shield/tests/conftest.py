"""Shared test configuration.

Makes `sentiala_core` importable without installation so the suite runs
with a plain `pytest` invocation from the repository root.
"""
import pathlib
import sys

CORE = pathlib.Path(__file__).resolve().parents[1] / "services" / "core"
if str(CORE) not in sys.path:
    sys.path.insert(0, str(CORE))
