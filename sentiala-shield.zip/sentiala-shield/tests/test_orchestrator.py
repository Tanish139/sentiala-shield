"""End-to-end pipeline tests: classification, orchestrator, history,
offline degradation, and report integrity (Sections 49-50)."""
import json
import os

import pytest

from sentiala_core.orchestrator import SentialaCore, classify_target
from sentiala_core.report import NO_INTELLIGENCE_FOUND, INTEL_UNAVAILABLE
from sentiala_core.report import to_json, to_markdown


@pytest.fixture
def clean_session():
    from test_providers import FakeResponse, FakeSession, load

    return FakeSession([
        ("POST", "urlhaus.abuse.ch",
         FakeResponse(200, load("urlhaus_no_results.json"))),
        ("GET", "rdap.org", FakeResponse(200, load("rdap_established.json"))),
        ("GET", "cloudflare-dns.com",
         FakeResponse(200, load("doh_answer.json"))),
    ])


@pytest.fixture
def core(tmp_path, clean_session):
    return SentialaCore(data_dir=str(tmp_path), session=clean_session)


# ------------------------------------------------------------ classification
def test_classify_target():
    assert classify_target("https://example.com/a").kind == "url"
    assert classify_target("example.com").kind == "domain"
    assert classify_target("93.184.216.34").kind == "ip"
    assert classify_target(
        "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    ).kind == "sha256"
    assert classify_target(
        "d41d8cd98f00b204e9800998ecf8427e"
    ).kind == "md5"
    assert classify_target("hello world").kind == "unknown"


def test_domain_scan_scheme_unknown_is_fair(core):
    report = core.scan("example.com")
    # no https penalty when scheme is unknown
    ids = [c["check_id"] for c in report["contributions"]]
    assert "no_https" not in ids


# ------------------------------------------------------------ clean pipeline
def test_clean_url_full_pipeline(core):
    report = core.scan("https://example.com/")
    assert report["schema"] == "sentiala.report/1"
    assert report["risk"]["score"] == 0
    assert report["risk"]["level"] == "SAFE"
    assert report["public_intelligence"] == NO_INTELLIGENCE_FOUND
    assert report["live_intelligence"]["providers"], "providers queried"
    assert all(p["available"] for p in report["live_intelligence"]["providers"])
    # Round-trip: the report must be valid JSON with no secrets
    json.loads(to_json(report))


def test_history_written(core, tmp_path):
    core.scan("https://example.com/")
    core.scan("http://malicious.test/download")
    history_file = tmp_path / "history.jsonl"
    assert history_file.exists()
    lines = history_file.read_text().strip().splitlines()
    assert len(lines) == 2
    entries = [json.loads(l) for l in lines]
    assert entries[0]["target"] == "https://example.com/"
    assert entries[1]["risk_score"] >= entries[0]["risk_score"]


# ------------------------------------------------------------ phishing pipeline
def test_phishing_like_url_scores_medium_or_worse(core):
    report = core.scan("http://paypal.com.verify-account.xyz/login")
    assert report["risk"]["score"] >= 20
    checks = [c["check_id"] for c in report["contributions"]]
    assert "brand_in_subdomain" in checks


def test_listed_host_scores_high(tmp_path):
    from test_providers import FakeResponse, FakeSession, load

    session = FakeSession([
        ("POST", "urlhaus.abuse.ch",
         FakeResponse(200, load("urlhaus_listed.json"))),
        ("GET", "rdap.org", FakeResponse(200, load("rdap_young.json"))),
        ("GET", "cloudflare-dns.com",
         FakeResponse(200, load("doh_answer.json"))),
    ])
    core = SentialaCore(data_dir=str(tmp_path), session=session)
    report = core.scan("http://malicious.test/download")
    checks = [c["check_id"] for c in report["contributions"]]
    assert "intel_urlhaus_listing" in checks
    assert report["risk"]["level"] in ("HIGH RISK", "CRITICAL")
    # verified facts must be present in the VERIFIED FACT evidence bucket
    assert report["evidence"]["VERIFIED FACT"]
    assert "relevant intelligence finding" in report["public_intelligence"]


# ------------------------------------------------------------ offline mode
def test_offline_mode_degrades(tmp_path):
    core = SentialaCore(data_dir=str(tmp_path), offline=True)
    report = core.scan("https://example.com/")
    assert report["live_intelligence"]["offline_mode"] is True
    assert report["live_intelligence"]["providers"] == []
    assert report["public_intelligence"] == INTEL_UNAVAILABLE
    assert report["live_intelligence"]["degradations"]
    # Offline verdict must be lower-confidence than a corroborated one
    offline_conf = report["risk"]["confidence"]
    assert offline_conf <= 80


def test_offline_still_detects_local_phishing(tmp_path):
    core = SentialaCore(data_dir=str(tmp_path), offline=True)
    report = core.scan("http://paypa1.com/login")
    assert report["risk"]["score"] >= 20
    assert report["risk"]["level"] in ("MEDIUM RISK", "HIGH RISK")


# ------------------------------------------------------------ partial outage
def test_partial_provider_outage_continues(tmp_path):
    from test_providers import FakeResponse, FakeSession, load

    # URLhaus reachable, RDAP down, DoH down
    session = FakeSession([
        ("POST", "urlhaus.abuse.ch",
         FakeResponse(200, load("urlhaus_no_results.json"))),
    ])
    core = SentialaCore(data_dir=str(tmp_path), session=session)
    report = core.scan("https://example.com/")
    states = {p["provider"]: p["available"]
              for p in report["live_intelligence"]["providers"]}
    assert states["URLhaus (abuse.ch)"] is True
    assert states["RDAP (registry data)"] is False
    assert states["Cloudflare DNS-over-HTTPS"] is False
    assert len(report["live_intelligence"]["degradations"]) == 2
    # Even with intel partly available, a clean target stays safe
    assert report["risk"]["level"] == "SAFE"


# ------------------------------------------------------------ target types
def test_ip_target_scans_without_crash(tmp_path):
    from test_providers import FakeResponse, FakeSession, load

    session = FakeSession([
        ("POST", "urlhaus.abuse.ch",
         FakeResponse(200, load("urlhaus_no_results.json"))),
    ])
    core = SentialaCore(data_dir=str(tmp_path), session=session)
    report = core.scan("203.0.113.9")
    assert report["target_kind"] == "ip"
    assert report["notes"]  # honest note about phase-1 limitations


def test_hash_target_is_rejected_honestly(core):
    report = core.scan("e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
    assert report["target_kind"] == "sha256"
    # No fabricated hash intelligence — the report says so explicitly
    assert "limited in this phase" in " ".join(report["notes"])


# ------------------------------------------------------------ report format
def test_markdown_report_sections(core):
    report = core.scan("https://example.com/")
    md = to_markdown(report)
    assert "SENTIALA THREAT INTELLIGENCE REPORT" in md
    # All four evidence taxonomy headings always present (Section 20)
    for heading in ("VERIFIED FACT", "OBSERVATION", "AI INFERENCE",
                   "UNVERIFIED CLAIM"):
        assert heading in md
    assert NO_INTELLIGENCE_FOUND in md
    assert "Recommended action" in md or "Recommended Action" in md
    assert "does not guarantee" in md  # honest disclaimer
