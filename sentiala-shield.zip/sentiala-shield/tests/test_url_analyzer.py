"""Layer 1 deterministic analyzer tests — safe and phishing-like fixtures
(Sections 49-50). All data is safe and synthetic; nothing is fetched."""
import pytest

from sentiala_core.url_analyzer import (
    analyze_url,
    confusable_normalize,
    levenshtein,
    split_host,
)


def ids(url, scheme_known=True):
    return {f.check_id for f in analyze_url(url, scheme_known) if f.points > 0}


# ---------------------------------------------------------------- safe cases
@pytest.mark.parametrize(
    "url",
    [
        "https://en.wikipedia.org/wiki/Phishing",
        "https://github.com/sentiala",
        "https://www.paypal.com/signin",
        "https://example.com/",
        "https://docs.python.org/3/library/urllib.parse.html",
        "https://www.bbc.co.uk/news",
    ],
)
def test_safe_urls_produce_no_risk_points(url):
    contributing = [f for f in analyze_url(url) if f.points > 0]
    assert contributing == [], f"unexpected findings for {url}: {contributing}"


def test_brand_legit_host_not_flagged():
    # www.paypal.com must not be treated as a typosquat of paypal
    assert "typosquatting" not in ids("https://www.paypal.com/signin")
    assert "brand_in_subdomain" not in ids("https://www.paypal.com/signin")


# ------------------------------------------------------- phishing-like cases
def test_typosquat_detected():
    assert "typosquatting" in ids("http://paypa1.com/login")
    assert "typosquatting" in ids("https://g00gle.com")


def test_homograph_detected():
    # xn--pypal-4ve.com decodes to a confusable of "paypal"
    found = ids("https://xn--pypal-4ve.com/verify")
    assert "homograph_domain" in found


def test_brand_in_subdomain_detected():
    found = ids("http://paypal.com.verify-account.xyz/login")
    assert "brand_in_subdomain" in found


def test_ip_literal_host():
    assert "ip_literal_host" in ids("http://192.0.2.123/login")


def test_credentials_in_url():
    assert "credentials_in_url" in ids(
        "http://admin:secret@files.example.com/"
    )


def test_dangerous_scheme():
    assert "dangerous_scheme" in ids("javascript:alert(1)")
    assert "dangerous_scheme" in ids("data:text/html;base64,PHNjcmlwdD4=")


def test_shortener_and_tld_and_keywords():
    assert "url_shortener" in ids("https://bit.ly/3xYz")
    assert "suspicious_tld" in ids("http://gift-cards.tk/")
    assert "suspicious_keywords" in ids(
        "http://regular-site.example/verify-account"
    )


def test_structural_checks():
    assert "many_subdomains" in ids(
        "https://a.b.c.d.exampleverylongnames.org/"
    )
    assert "excessive_hyphens" in ids(
        "http://secure-login-verify-account-online.example.org/"
    )
    assert "nonstandard_port" in ids("https://example.com:8443/")


def test_long_url():
    url = "https://example.com/" + "a" * 150
    assert "long_url" in ids(url)


def test_unparseable():
    findings = analyze_url("not a url at all")
    assert "unparseable_url" in {f.check_id for f in findings}


def test_no_https_penalised():
    assert "no_https" in ids("http://example.com/")


def test_domain_scan_scheme_unknown_no_https_penalty():
    # Bare domain: scheme unknown -> no penalty either way (fairness)
    findings = analyze_url("http://example.com/", scheme_known=False)
    assert "no_https" not in {f.check_id for f in findings}
    assert "https" not in {f.check_id for f in findings}


def test_https_is_mitigating_not_risk():
    findings = analyze_url("https://example.com/")
    https = [f for f in findings if f.check_id == "https"]
    assert https and https[0].mitigating and https[0].points == 0


# ------------------------------------------------------------------ helpers
def test_split_host():
    assert split_host("www.bbc.co.uk") == ("www", "bbc", "co.uk")
    assert split_host("a.b.example.com") == ("a.b", "example", "com")
    assert split_host("example.com") == ("", "example", "com")


def test_levenshtein():
    assert levenshtein("paypal", "paypal") == 0
    assert levenshtein("paypal", "paypa1") == 1
    assert levenshtein("g00gle", "google") == 2


def test_confusable_normalize():
    # Cyrillic 'а' folds to latin 'a'
    assert confusable_normalize("pаypal") == "paypal"  # noqa: RUF001
    assert confusable_normalize("päypal") == "paypal"
