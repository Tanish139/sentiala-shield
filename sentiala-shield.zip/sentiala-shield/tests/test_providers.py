"""Provider adapter tests using recorded synthetic responses — no network
required (Sections 49-50: conflicting intelligence, no-intelligence
scenarios, provider failures)."""
import json
from datetime import datetime, timezone

import pytest

from sentiala_core.providers import (
    DnsOverHttpsProvider,
    RdapProvider,
    URLhausProvider,
)
from sentiala_core.types import ScanContext

FIXTURES = __file__.rsplit("/", 1)[0] + "/fixtures"


class FakeResponse:
    def __init__(self, status_code=200, payload=None):
        self.status_code = status_code
        self._payload = payload

    def json(self):
        if self._payload is None:
            raise ValueError("no JSON body")
        return self._payload


class FakeSession:
    """Replays recorded responses; records calls for assertions."""

    def __init__(self, routes=None):
        self.routes = routes or []  # (method, url_substring, response)
        self.calls = []

    def _match(self, method, url):
        self.calls.append((method, url))
        for m, needle, resp in self.routes:
            if m == method and needle in url:
                return resp
        raise ConnectionError(f"no route for {method} {url}")

    def get(self, url, **kw):
        return self._match("GET", url)

    def post(self, url, **kw):
        return self._match("POST", url)


def ctx_for(target):
    from sentiala_core.orchestrator import classify_target
    return classify_target(target)


def load(name):
    with open(f"{FIXTURES}/{name}", encoding="utf-8") as fh:
        return json.load(fh)


@pytest.fixture
def urlhaus_listed_session():
    return FakeSession([(
        "POST", "urlhaus.abuse.ch",
        FakeResponse(200, load("urlhaus_listed.json")),
    )])


@pytest.fixture
def urlhaus_clean_session():
    return FakeSession([(
        "POST", "urlhaus.abuse.ch",
        FakeResponse(200, load("urlhaus_no_results.json")),
    )])


@pytest.fixture
def full_clean_session():
    return FakeSession([
        ("POST", "urlhaus.abuse.ch",
         FakeResponse(200, load("urlhaus_no_results.json"))),
        ("GET", "rdap.org",
         FakeResponse(200, load("rdap_established.json"))),
        ("GET", "cloudflare-dns.com",
         FakeResponse(200, load("doh_answer.json"))),
    ])


# ---------------------------------------------------------------- URLhaus
def test_urlhaus_listed_is_verified_fact(urlhaus_listed_session):
    provider = URLhausProvider(session=urlhaus_listed_session)
    result = provider.query(ctx_for("http://malicious.test/download"))
    assert result.available
    assert len(result.findings) == 1
    f = result.findings[0]
    assert f.evidence_class.value == "VERIFIED FACT"
    assert f.points == 45
    assert int(f.source.tier) == 2
    assert f.check_id == "intel_urlhaus_listing"


def test_urlhaus_clean(urlhaus_clean_session):
    provider = URLhausProvider(session=urlhaus_clean_session)
    result = provider.query(ctx_for("http://benign.test/"))
    assert result.available
    assert result.findings == []


def test_provider_failure_degrades_not_crashes():
    provider = URLhausProvider(session=FakeSession())
    result = provider.query(ctx_for("http://unreachable.test/"))
    assert result.available is False
    assert "ConnectionError" in result.note
    assert result.findings == []


def test_unexpected_query_status_is_not_a_match():
    session = FakeSession([(
        "POST", "urlhaus.abuse.ch", FakeResponse(200, {"query_status": "wat"}),
    )])
    result = URLhausProvider(session=session).query(
        ctx_for("http://odd.test/")
    )
    assert result.available is False  # refuse to guess, refuse to fake


# ---------------------------------------------------------------- RDAP
def test_rdap_young_domain_flagged():
    session = FakeSession([(
        "GET", "rdap.org", FakeResponse(200, load("rdap_young.json")),
    )])
    provider = RdapProvider(
        session=session,
        now=lambda: datetime(2026, 9, 28, tzinfo=timezone.utc),
    )
    result = provider.query(ctx_for("http://brand-new.test/"))
    assert result.available
    f = result.findings[0]
    assert f.check_id == "rdap_young_domain"
    assert f.points == 15
    assert f.evidence_class.value == "VERIFIED FACT"


def test_rdap_established_domain_is_mitigating():
    session = FakeSession([(
        "GET", "rdap.org", FakeResponse(200, load("rdap_established.json")),
    )])
    provider = RdapProvider(session=session)
    result = provider.query(ctx_for("http://old-faithful.test/"))
    f = result.findings[0]
    assert f.check_id == "rdap_established_domain"
    assert f.mitigating and f.points == 0


def test_rdap_404_is_observation_not_fact():
    session = FakeSession([("GET", "rdap.org", FakeResponse(404))])
    provider = RdapProvider(session=session)
    result = provider.query(ctx_for("http://not-in-rdap.test/"))
    f = result.findings[0]
    assert f.check_id == "rdap_not_found"
    assert f.evidence_class.value == "OBSERVATION"
    assert f.points == 6


# ---------------------------------------------------------------- DoH
def test_doh_no_resolution():
    session = FakeSession([(
        "GET", "cloudflare-dns.com",
        FakeResponse(200, load("doh_nxdomain.json")),
    )])
    result = DnsOverHttpsProvider(session=session).query(
        ctx_for("http://doesnotresolve.test/")
    )
    f = result.findings[0]
    assert f.check_id == "dns_no_resolution"
    assert f.evidence_class.value == "OBSERVATION"


def test_doh_resolves_no_findings():
    session = FakeSession([(
        "GET", "cloudflare-dns.com",
        FakeResponse(200, load("doh_answer.json")),
    )])
    result = DnsOverHttpsProvider(session=session).query(
        ctx_for("http://resolves.test/")
    )
    assert result.available
    assert result.findings == []


# ---------------------------------------------------------------- cache
def test_results_are_cached_per_host(tmp_path, urlhaus_clean_session):
    from sentiala_core.cache import TTLCache

    cache = TTLCache(path=str(tmp_path / "cache.json"))
    provider = URLhausProvider(session=urlhaus_clean_session, cache=cache)
    provider.query(ctx_for("http://benign.test/"))
    provider.query(ctx_for("http://benign.test/"))
    assert len(urlhaus_clean_session.calls) == 1  # second hit from cache


def test_cached_result_survives_restart(tmp_path, urlhaus_clean_session):
    from sentiala_core.cache import TTLCache

    cache = TTLCache(path=str(tmp_path / "cache.json"))
    URLhausProvider(session=urlhaus_clean_session, cache=cache).query(
        ctx_for("http://benign.test/")
    )
    cache2 = TTLCache(path=str(tmp_path / "cache.json"))
    provider2 = URLhausProvider(session=FakeSession(), cache=cache2)
    result = provider2.query(ctx_for("http://benign.test/"))
    assert result.available and result.findings == []
    assert provider2.session.calls == []  # served entirely from disk cache
