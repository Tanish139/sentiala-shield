"""AI-correlation and anti-fabrication tests (Sections 21, 49).

The most important tests in the repository: nothing may ever fabricate
evidence, and explanations must only restate findings that exist."""
import json

import pytest

from sentiala_core.ai import LocalCorrelator
from sentiala_core.orchestrator import SentialaCore
from sentiala_core.report import build_report, to_json, to_markdown
from sentiala_core.risk_engine import assess
from sentiala_core.types import EvidenceClass, Finding


def test_explanation_of_clean_target_mentions_no_evidence_found():
    ai = LocalCorrelator()
    a = assess([])
    text = ai.explain("https://example.com/", a, [])
    assert "no contributing risk indicators" in text
    assert "not proof of safety" in text  # honest about absence of evidence


def test_explanation_only_restates_existing_findings():
    ai = LocalCorrelator()
    findings = [
        Finding("typosquatting", "Possible typosquat of 'paypal.com'",
                "detail", EvidenceClass.OBSERVATION, 30),
    ]
    a = assess(findings)
    text = ai.explain("http://paypa1.com/", a, findings)
    assert "paypa1" in text
    # must not mention checks that were never run
    for absent in ("homograph", "URLhaus", "RDAP", "DNS"):
        assert absent.lower() not in text.lower()


def test_explanation_distinguishes_verified_from_inferred():
    ai = LocalCorrelator()
    findings = [
        Finding("intel_urlhaus_listing", "Host listed on URLhaus",
                "detail", EvidenceClass.VERIFIED_FACT, 45),
        Finding("no_https", "No HTTPS", "detail", EvidenceClass.OBSERVATION, 8),
    ]
    text = ai.explain("http://bad.test/", assess(findings), findings)
    assert "verified facts" in text
    assert "deterministic observations" in text


def test_clean_report_never_claims_verification():
    findings = [Finding("https", "HTTPS", "detail",
                       EvidenceClass.OBSERVATION, 0, mitigating=True)]
    report = build_report(
        target="https://example.com/",
        kind="url",
        url_findings=findings,
        intel_results=[],
        assessment=assess(findings, live_intel_available=False),
        ai_explanation="x",
        generated_at="2026-01-01T00:00:00+00:00",
        offline=True,
    )
    assert report["public_intelligence"] == "UNVERIFIED — live intelligence unavailable"
    assert report["evidence"]["VERIFIED FACT"] == []
    md = to_markdown(report)
    assert "_None for this investigation._" in md


def test_report_json_roundtrip(tmp_path):
    findings = [
        Finding("typosquatting", "t", "d", EvidenceClass.OBSERVATION, 30),
    ]
    report = build_report(
        target="http://paypa1.com/", kind="url", url_findings=findings,
        intel_results=[], assessment=assess(findings),
        ai_explanation="explanation text",
        generated_at="2026-01-01T00:00:00+00:00",
    )
    data = json.loads(to_json(report))
    assert data["risk"]["score"] == report["risk"]["score"]
    (tmp_path / "r.json").write_text(to_json(report))
    assert json.loads((tmp_path / "r.json").read_text()) == data


def test_no_placeholder_or_fabrication_markers():
    """Reports must not contain placeholder text masquerading as evidence."""
    findings = [Finding("x", "t", "d", EvidenceClass.OBSERVATION, 10)]
    report = build_report(
        target="http://example.test/", kind="url", url_findings=findings,
        intel_results=[], assessment=assess(findings),
        ai_explanation="e", generated_at="2026-01-01T00:00:00+00:00",
    )
    blob = to_json(report)
    for banned in ("TODO", "FIXME", "lorem", "fake ", "dummy",
                   "example finding", "placeholder"):
        assert banned.lower() not in blob.lower()
