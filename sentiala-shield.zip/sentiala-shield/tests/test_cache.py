"""Cache behaviour tests (Section 49)."""
from sentiala_core.cache import TTLCache


class FakeClock:
    def __init__(self):
        self.t = 1000.0

    def __call__(self):
        return self.t

    def advance(self, seconds):
        self.t += seconds


def test_set_get_roundtrip():
    cache = TTLCache(clock=FakeClock())
    cache.set("k", {"a": 1})
    assert cache.get("k") == {"a": 1}


def test_missing_key_returns_none():
    assert TTLCache(clock=FakeClock()).get("nope") is None


def test_expiry():
    clock = FakeClock()
    cache = TTLCache(clock=clock)
    cache.set("k", "v", ttl=60)
    clock.advance(59)
    assert cache.get("k") == "v"
    clock.advance(2)
    assert cache.get("k") is None


def test_default_ttl_used():
    clock = FakeClock()
    cache = TTLCache(default_ttl=10, clock=clock)
    cache.set("k", "v")
    clock.advance(11)
    assert cache.get("k") is None


def test_disk_persistence(tmp_path):
    path = str(tmp_path / "c.json")
    TTLCache(path=path, clock=FakeClock()).set("k", {"x": [1, 2]})
    revived = TTLCache(path=path, clock=FakeClock())
    assert revived.get("k") == {"x": [1, 2]}


def test_corrupt_cache_file_is_ignored(tmp_path):
    bad = tmp_path / "bad.json"
    bad.write_text("{not json")
    cache = TTLCache(path=str(bad), clock=FakeClock())
    assert cache.get("anything") is None  # no crash, no phantom data
