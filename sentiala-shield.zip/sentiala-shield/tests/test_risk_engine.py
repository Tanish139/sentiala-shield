"""Risk engine tests — thresholds, family suppression, confidence,
explainability (Section 49)."""
from sentiala_core.risk_engine import assess
from sentiala_core.types import EvidenceClass, Finding, RiskLevel


def mk(check_id, points, cls=EvidenceClass.OBSERVATION, mitigating=False):
    return Finding(check_id, "title", "detail", cls, points,
                   mitigating=mitigating)


def test_zero_findings_is_safe():
    a = assess([])
    assert a.score == 0
    assert a.level is RiskLevel.SAFE
    assert 30 <= a.confidence <= 97


def test_mitigating_https_counts_toward_safe_confidence():
    clean = assess([mk("https", 0, mitigating=True)], live_intel_available=True)
    assert clean.level is RiskLevel.SAFE
    assert clean.mitigating_factors


def test_level_thresholds():
    assert assess([mk("a", 4)]).level is RiskLevel.SAFE
    assert assess([mk("a", 5)]).level is RiskLevel.LOW_RISK
    assert assess([mk("a", 20)]).level is RiskLevel.MEDIUM_RISK
    assert assess([mk("a", 50)]).level is RiskLevel.HIGH_RISK
    assert assess([mk("a", 80)]).level is RiskLevel.CRITICAL


def test_impersonation_family_only_strongest_counts():
    mixed = assess([
        mk("homograph_domain", 35),
        mk("typosquatting", 30),
        mk("brand_in_subdomain", 22),
    ])
    assert mixed.score == 35  # max of family, not sum
    assert mixed.level is RiskLevel.MEDIUM_RISK


def test_independent_findings_sum():
    both = assess([mk("credentials_in_url", 30), mk("ip_literal_host", 22)])
    assert both.score == 52
    assert both.level is RiskLevel.HIGH_RISK


def test_score_clamped_at_100():
    many = assess([
        mk("dangerous_scheme", 60),
        mk("intel_urlhaus_listing", 45, EvidenceClass.VERIFIED_FACT),
        mk("credentials_in_url", 30),
    ])
    assert many.score == 100
    assert many.level is RiskLevel.CRITICAL


def test_offline_lowers_confidence():
    findings = [mk("typosquatting", 30)]
    online = assess(findings, live_intel_available=True)
    offline = assess(findings, live_intel_available=False)
    assert offline.confidence < online.confidence


def test_verified_evidence_raises_confidence():
    weak = assess([mk("suspicious_tld", 12)])
    strong = assess([mk("intel_urlhaus_listing", 45, EvidenceClass.VERIFIED_FACT)])
    assert strong.confidence > weak.confidence


def test_contributions_sorted_and_explainable():
    a = assess([mk("no_https", 8), mk("typosquatting", 30),
                mk("suspicious_tld", 12)])
    pts = [c["points"] for c in a.contributions]
    assert pts == sorted(pts, reverse=True)
    for c in a.contributions:
        assert set(c) == {"check_id", "title", "points",
                          "evidence_class", "source"}


def test_recommended_action_always_present():
    for findings in ([], [mk("a", 10)], [mk("a", 90)]):
        assert assess(findings).recommended_action
