"""Sentiala orchestrator — the scan pipeline (Sections 5, 58, 64).

Vertical slice flow:

    target
      -> classification (url / domain / ip / hash)
      -> Layer 1  deterministic URL analysis
      -> Layer 2  threat-intelligence providers (parallel-safe, keyless)
      -> Layer 5  risk engine
      -> Layer 4  AI correlation/explanation
      -> Layer 6  report (JSON + Markdown) & local history

Sentiala never fetches the target URL. Intelligence providers only
receive the hostname of the indicator being investigated.

Offline mode (Section 45) skips all network providers and lowers the
confidence of the resulting verdict — clearly, not silently.
"""
from __future__ import annotations

import ipaddress
import logging
import os
import re
from datetime import datetime, timezone
from typing import Optional

import requests

from .ai import AIProvider, LocalCorrelator
from .cache import TTLCache
from .history import History
from .providers import (
    DnsOverHttpsProvider,
    Provider,
    RdapProvider,
    URLhausProvider,
)
from .report import build_report
from .risk_engine import assess
from .types import ScanContext
from .url_analyzer import analyze_url

logger = logging.getLogger("sentiala")

_HASH_RE = re.compile(r"^[0-9a-fA-F]+$")

# Tool permission system (Section 59) — the orchestrator can only invoke
# capabilities listed here. Read-only public lookups are allowed by
# default; anything touching local files or private data is not
# implemented in this phase at all.
TOOL_PERMISSIONS = {
    "URL_ANALYSIS": "ALLOWED",
    "DOMAIN_LOOKUP": "ALLOWED",
    "DNS_RESOLUTION": "ALLOWED",
    "THREAT_INTEL_LOOKUP": "ALLOWED",
    "FILE_METADATA": "NOT IMPLEMENTED (planned, will require user approval)",
    "PRIVATE_FILE_ACCESS": "DENIED",
    "CREDENTIAL_ACCESS": "DENIED",
    "REMOTE_CONTROL": "DENIED",
}


def classify_target(raw: str) -> ScanContext:
    target = raw.strip()
    if _HASH_RE.fullmatch(target or ""):
        if len(target) == 64:
            kind = "sha256"
        elif len(target) == 40:
            kind = "sha1"
        elif len(target) == 32:
            kind = "md5"
        else:
            kind = "unknown"
        return ScanContext(target=target, kind=kind)

    try:
        ipaddress.ip_address(target)
        return ScanContext(target=target, kind="ip")
    except ValueError:
        pass

    candidate = target if "://" in target else f"http://{target}"
    from urllib.parse import urlparse

    try:
        parsed = urlparse(candidate)
    except ValueError:
        return ScanContext(target=target, kind="unknown")
    host = (parsed.hostname or "").lower()
    if not host or " " in target:
        return ScanContext(target=target, kind="unknown")

    if "://" in target:
        return ScanContext(
            target=target, kind="url", url=target, host=host,
            scheme_known=parsed.scheme.lower() in ("http", "https", ""),
        )
    return ScanContext(
        target=target, kind="domain", url=candidate, host=host,
        scheme_known=False,
    )


class SentialaCore:
    """Composable scan engine used by the CLI, the future local agent,
    and the future dashboard API."""

    def __init__(
        self,
        data_dir: Optional[str] = None,
        offline: bool = False,
        session: Optional[requests.Session] = None,
        extra_providers: Optional[list[Provider]] = None,
        ai_provider: Optional[AIProvider] = None,
    ) -> None:
        self.offline = offline
        self.data_dir = data_dir
        self.ai = ai_provider or LocalCorrelator()

        cache_path = (
            os.path.join(data_dir, "intel_cache.json") if data_dir else None
        )
        cache = TTLCache(path=cache_path)
        self.providers: list[Provider] = [
            URLhausProvider(session=session, cache=cache),
            RdapProvider(session=session, cache=cache),
            DnsOverHttpsProvider(session=session, cache=cache),
        ]
        if extra_providers:
            self.providers.extend(extra_providers)

        self.history = History(
            os.path.join(data_dir, "history.jsonl") if data_dir else None
        )

    # ------------------------------------------------------------------
    def scan(self, target: str) -> dict:
        started = datetime.now(timezone.utc)
        ctx = classify_target(target)
        degradations: list[str] = []
        notes: list[str] = []
        url_findings = []

        if ctx.kind in ("url", "domain"):
            url_findings = analyze_url(
                ctx.url or ctx.target, scheme_known=ctx.scheme_known
            )
            if ctx.kind == "domain":
                notes.append(
                    "Bare domain scan: the scheme is unknown, so HTTPS "
                    "checks were skipped (no penalty applied)."
                )
        elif ctx.kind in ("ip", "sha256", "sha1", "md5"):
            notes.append(
                f"Target classified as {ctx.kind.upper()}. Deterministic "
                f"URL analysis does not apply; external intelligence "
                f"lookups for this target type are limited in this phase "
                f"(full IP/hash intelligence ships in a later phase)."
            )
        else:
            notes.append(
                "Target could not be classified; no analysis was possible."
            )

        intel_results = []
        if self.offline:
            degradations.append(
                "Offline mode active — live intelligence was not consulted. "
                "Verdict relies on local deterministic rules only and "
                "confidence is reduced."
            )
            if ctx.kind not in ("url", "domain"):
                notes.append("Offline mode: no intelligence lookup performed.")
        else:
            for provider in self.providers:
                if ctx.kind == "unknown":
                    break
                result = provider.query(ctx)
                intel_results.append(result)
                if not result.available:
                    degradations.append(
                        f"{provider.name} unavailable "
                        f"({result.note[:90]}) — continuing without it."
                    )

        live_intel = any(r.available for r in intel_results)
        findings = list(url_findings) + [
            f for r in intel_results for f in r.findings
        ]
        assessment = assess(findings, live_intel_available=live_intel)
        explanation = self.ai.explain(ctx.target, assessment, findings)
        report = build_report(
            target=ctx.target,
            kind=ctx.kind,
            url_findings=url_findings,
            intel_results=intel_results,
            assessment=assessment,
            ai_explanation=explanation,
            generated_at=started.isoformat(timespec="seconds"),
            offline=self.offline,
            degradations=degradations,
            notes=notes,
        )

        self.history.append(
            {
                "timestamp": report["generated_at"],
                "target": ctx.target,
                "kind": ctx.kind,
                "risk_score": assessment.score,
                "level": assessment.level.value,
                "confidence": assessment.confidence,
                "evidence_items": len(findings),
                "offline": self.offline,
            }
        )
        logger.info(
            "scan complete target=%s level=%s score=%d",
            ctx.target, assessment.level.value, assessment.score,
        )
        return report
