"""Layer 6 — explainability and report generation (Sections 19-21, 37).

Every investigation produces a structured JSON report and a human-readable
Markdown report. Both are built *only* from evidence that exists; when no
public intelligence was found the report says exactly that, per the
no-hallucination rule (Section 21).
"""
from __future__ import annotations

import json
from typing import Any, Dict, List

from .ai import LocalCorrelator
from .types import (
    EvidenceClass,
    Finding,
    IntelligenceResult,
    RiskAssessment,
    RiskLevel,
    Source,
)

NO_INTELLIGENCE_FOUND = "NO RELEVANT PUBLIC INTELLIGENCE FOUND"
INTEL_UNAVAILABLE = "UNVERIFIED — live intelligence unavailable"

_LEVEL_ICON = {
    RiskLevel.SAFE: "🟢",
    RiskLevel.LOW_RISK: "🟢",
    RiskLevel.MEDIUM_RISK: "🟡",
    RiskLevel.HIGH_RISK: "🟠",
    RiskLevel.CRITICAL: "🔴",
}


def _dedupe_sources(findings: List[Finding]) -> List[Source]:
    seen: dict[str, Source] = {}
    for f in findings:
        if f.source and f.source.name not in seen:
            seen[f.source.name] = f.source
    return list(seen.values())


def build_report(
    target: str,
    kind: str,
    url_findings: List[Finding],
    intel_results: List[IntelligenceResult],
    assessment: RiskAssessment,
    ai_explanation: str,
    generated_at: str,
    offline: bool = False,
    degradations: List[str] | None = None,
    notes: List[str] | None = None,
) -> Dict[str, Any]:
    findings = list(url_findings) + [
        f for r in intel_results for f in r.findings
    ]
    intel_findings = [f for r in intel_results for f in r.findings]
    # Only threat-relevant intel (risk contributions) counts as "found";
    # neutral/mitigating registry facts are intelligence, not evidence of a
    # threat, and must not be reported as such.
    intel_risk_findings = [f for f in intel_findings if f.points > 0]
    providers_available = [r for r in intel_results if r.available]

    # Public intelligence status (Section 21 — never fabricate).
    if offline or not providers_available:
        public_intelligence = INTEL_UNAVAILABLE
    elif not intel_risk_findings:
        public_intelligence = NO_INTELLIGENCE_FOUND
    else:
        public_intelligence = (
            f"{len(intel_risk_findings)} relevant intelligence finding(s) found"
        )

    return {
        "schema": "sentiala.report/1",
        "product": "Sentiala Shield",
        "target": target,
        "target_kind": kind,
        "generated_at": generated_at,
        "risk": {
            "score": assessment.score,
            "level": assessment.level.value,
            "confidence": assessment.confidence,
            "recommended_action": assessment.recommended_action,
        },
        "public_intelligence": public_intelligence,
        "evidence": {
            cls.value: [f.to_dict() for f in findings
                        if f.evidence_class == cls]
            for cls in EvidenceClass
        },
        "contributions": assessment.contributions,
        "possible_false_positives": assessment.mitigating_factors,
        "ai_explanation": ai_explanation,
        "live_intelligence": {
            "offline_mode": offline,
            "providers": [r.to_dict() for r in intel_results],
            "degradations": degradations or [],
        },
        "notes": notes or [],
        "sources": [s.to_dict() for s in _dedupe_sources(findings)],
        "disclaimer": (
            "Sentiala provides evidence-based security assistance. It does "
            "not guarantee detection of every threat, and a SAFE verdict "
            "means 'no significant evidence found', not 'verified safe'."
        ),
    }


def to_markdown(report: Dict[str, Any]) -> str:
    risk = report["risk"]
    level = risk["level"]
    icon = _LEVEL_ICON.get(RiskLevel(level), "⚪")
    lines: List[str] = []
    add = lines.append

    add("# SENTIALA THREAT INTELLIGENCE REPORT")
    add("")
    add(f"**Target:** `{report['target']}`  ")
    add(f"**Target type:** {report['target_kind']}  ")
    add(f"**Generated:** {report['generated_at']}  ")
    add(f"**Threat level:** {icon} **{level}**  ")
    add(f"**Risk score:** **{risk['score']}/100**  ")
    add(f"**Confidence:** **{risk['confidence']}%**")
    add("")
    add(f"**Public intelligence status:** {report['public_intelligence']}")
    add("")

    add("## Why Sentiala assesses this risk")
    add("")
    add(report["ai_explanation"])
    add("")

    add("## Evidence")
    add("")
    for cls in EvidenceClass:
        items = report["evidence"][cls.value]
        add(f"### {cls.value}")
        add("")
        if not items:
            add("_None for this investigation._")
        for item in items:
            src = item.get("source")
            if src:
                add(
                    f"- **{item['title']}** (+{item['points']} pts) — "
                    f"{item['detail']} "
                    f"_(source: {src['name']}, {src['tier_label']}, "
                    f"{src['retrieved_at']})_"
                )
            else:
                add(
                    f"- **{item['title']}** (+{item['points']} pts) — "
                    f"{item['detail']}"
                )
        add("")

    add("## Score contributions")
    add("")
    if report["contributions"]:
        add("| Indicator | Points | Evidence class | Source |")
        add("|---|---|---|---|")
        for c in report["contributions"]:
            add(
                f"| {c['title']} | {c['points']} | {c['evidence_class']} | "
                f"{c['source']} |"
            )
    else:
        add("_No contributing risk indicators — score 0._")
    add("")

    add("## Possible false positives")
    add("")
    for factor in report["possible_false_positives"]:
        add(f"- {factor}")
    add("")

    add("## Live intelligence status")
    add("")
    li = report["live_intelligence"]
    if li["offline_mode"]:
        add("- **OFFLINE MODE** — live intelligence was not consulted; "
            "assessment uses local rules only.")
    for p in li["providers"]:
        state = "available" if p["available"] else "unavailable"
        add(f"- {p['provider']}: {state}" + (f" ({p['note']})" if p["note"] else ""))
    for d in li["degradations"]:
        add(f"- Degradation: {d}")
    add("")

    add("## Recommended action")
    add("")
    add(f"**{risk['recommended_action']}**")
    add("")

    if report["notes"]:
        add("## Notes")
        add("")
        for n in report["notes"]:
            add(f"- {n}")
        add("")

    if report["sources"]:
        add("## Sources")
        add("")
        for s in report["sources"]:
            add(f"- {s['name']} — {s['tier_label']}"
                + (f" ({s['url']})" if s["url"] else ""))
        add("")

    add("---")
    add(f"_{report['disclaimer']}_")
    return "\n".join(lines)


def to_json(report: Dict[str, Any]) -> str:
    return json.dumps(report, indent=2, ensure_ascii=False)
