"""RDAP adapter — domain registration intelligence (Section 12).

Uses the free, keyless, registry-operated RDAP bootstrap service
(https://rdap.org). Registry data is Tier 1 (protocol infrastructure
operated by registries/registrars per IETF standards).

Signals derived:
* very recently registered domain  -> elevated risk observation
* long-established domain           -> mitigating factor (false-positive context)
* domain absent from RDAP           -> observation (may be unregistered or
  an exotic TLD; RDAP coverage is not universal — stated, not hidden)
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Callable, Optional

from ..types import (
    EvidenceClass,
    Finding,
    IntelligenceResult,
    ScanContext,
    SourceTier,
)
from .base import Provider

NEW_DOMAIN_DAYS = 60
ESTABLISHED_DOMAIN_DAYS = 730


class RdapProvider(Provider):
    name = "RDAP (registry data)"
    tier = SourceTier.TIER1
    description = "Domain registration data via the rdap.org bootstrap service"
    source_url = "https://rdap.org/"
    default_ttl = 21600  # registration data changes rarely

    def __init__(
        self,
        session=None,
        cache=None,
        timeout: int = 15,
        now: Optional[Callable[[], datetime]] = None,
    ) -> None:
        super().__init__(session=session, cache=cache, timeout=timeout)
        self._now = now or (lambda: datetime.now(timezone.utc))

    def supports(self, ctx: ScanContext) -> bool:
        # RDAP is domain-only; IP lookups are a separate planned provider.
        return bool(ctx.host) and ctx.kind in ("domain", "url")

    def _query(self, ctx: ScanContext) -> IntelligenceResult:
        domain = ctx.host
        resp = self.session.get(
            f"https://rdap.org/domain/{domain}", timeout=self.timeout
        )
        if resp.status_code == 404:
            return IntelligenceResult(
                provider=self.name,
                findings=[
                    Finding(
                        check_id="rdap_not_found",
                        title="Domain not found in RDAP",
                        detail=(
                            f"'{domain}' returned no RDAP record. This can mean "
                            f"the domain is unregistered, or the TLD lacks full "
                            f"RDAP coverage. Treated as an observation, not "
                            f"proof of maliciousness."
                        ),
                        evidence_class=EvidenceClass.OBSERVATION,
                        points=6,
                        source=self.source(),
                    )
                ],
                note="no RDAP record",
            )
        if resp.status_code != 200:
            return IntelligenceResult(
                provider=self.name,
                available=False,
                note=f"RDAP returned HTTP {resp.status_code}",
            )

        data = resp.json()
        registered = None
        for event in data.get("events", []):
            if event.get("eventAction") == "registration":
                try:
                    registered = datetime.fromisoformat(
                        event["eventDate"].replace("Z", "+00:00")
                    )
                except (KeyError, ValueError):
                    continue
        if registered is None:
            return IntelligenceResult(
                provider=self.name,
                note="RDAP record present; no registration date disclosed",
            )

        if registered.tzinfo is None:
            registered = registered.replace(tzinfo=timezone.utc)
        age_days = (self._now() - registered).days

        if age_days < 0:
            age_days = 0

        if age_days <= NEW_DOMAIN_DAYS:
            finding = Finding(
                check_id="rdap_young_domain",
                title=f"Domain registered only {age_days} days ago",
                detail=(
                    f"'{domain}' was registered on "
                    f"{registered.date().isoformat()}. Phishing "
                    f"infrastructure is frequently brand new; legitimate "
                    f"established sites are rarely this young."
                ),
                evidence_class=EvidenceClass.VERIFIED_FACT,
                points=15,
                source=self.source(),
            )
        elif age_days >= ESTABLISHED_DOMAIN_DAYS:
            finding = Finding(
                check_id="rdap_established_domain",
                title=f"Domain registered ~{age_days // 365} years ago",
                detail=(
                    f"'{domain}' has existed since "
                    f"{registered.date().isoformat()}. Long registration "
                    f"history lowers (but does not eliminate) phishing "
                    f"likelihood — compromised sites also occur."
                ),
                evidence_class=EvidenceClass.VERIFIED_FACT,
                points=0,
                source=self.source(),
                mitigating=True,
            )
        else:
            finding = Finding(
                check_id="rdap_domain_age",
                title=f"Domain registered {age_days} days ago",
                detail=(
                    f"'{domain}' was registered on "
                    f"{registered.date().isoformat()} (registry data via RDAP)."
                ),
                evidence_class=EvidenceClass.VERIFIED_FACT,
                points=0,
                source=self.source(),
            )

        return IntelligenceResult(provider=self.name, findings=[finding])
