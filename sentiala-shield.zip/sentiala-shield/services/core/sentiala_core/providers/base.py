"""Threat-intelligence provider abstraction (Sections 41-42).

Sentiala never hard-couples to a single intelligence service. Every source
is an adapter implementing ``Provider``. If one provider is unreachable or
rate-limited, the pipeline continues with the others and reports the
degradation instead of failing (graceful degradation, Section 41).

Providers accept an injectable ``requests.Session`` so tests can replay
recorded responses without network access. All providers in this package
are **free, keyless, public** services. Keyed providers (Google Safe
Browsing, PhishTank, VirusTotal, etc.) are planned for Phase 4 and will
read credentials from environment variables only — never from source.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import datetime, timezone
from typing import Callable, Optional

import requests

from ..cache import TTLCache
from ..types import (
    EvidenceClass,
    Finding,
    IntelligenceResult,
    ScanContext,
    Source,
    SourceTier,
)


def _utcnow_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class Provider(ABC):
    """Base class for all intelligence adapters.

    ``query`` never raises: transport failures surface as
    ``available=False`` results which the orchestrator turns into honest
    degradations rather than false "all clear" verdicts.
    """

    name: str = "provider"
    tier: SourceTier = SourceTier.TIER4
    description: str = ""
    default_ttl: int = 3600

    def __init__(
        self,
        session: Optional[requests.Session] = None,
        cache: Optional[TTLCache] = None,
        timeout: int = 15,
    ) -> None:
        self.session = session or requests.Session()
        self.cache = cache
        self.timeout = timeout

    # -- public API ---------------------------------------------------------
    def query(self, ctx: ScanContext) -> IntelligenceResult:
        if not self.supports(ctx):
            return IntelligenceResult(
                provider=self.name,
                note=f"target kind '{ctx.kind}' not supported by this provider",
            )
        if self.cache is not None:
            key = self._cache_key(ctx)
            if key:
                cached = self.cache.get(key)
                if cached is not None:
                    return _result_from_dict(self.name, cached)
        try:
            result = self._query(ctx)
        except Exception as exc:  # noqa: BLE001 — providers must never raise
            return IntelligenceResult(
                provider=self.name,
                available=False,
                note=f"{type(exc).__name__}: {str(exc)[:180]}",
            )
        if self.cache is not None:
            key = self._cache_key(ctx)
            if key:
                # Store only JSON-serialisable data on disk (privacy: the
                # cache holds provider responses about public indicators,
                # never user content or full URLs).
                self.cache.set(key, result.to_dict(), ttl=self.default_ttl)
        return result

    def supports(self, ctx: ScanContext) -> bool:
        return bool(ctx.host)

    def source(self) -> Source:
        return Source(
            name=self.name,
            tier=self.tier,
            url=getattr(self, "source_url", ""),
            retrieved_at=_utcnow_iso(),
        )

    # -- override points ------------------------------------------------------
    @abstractmethod
    def _query(self, ctx: ScanContext) -> IntelligenceResult:
        ...

    def _cache_key(self, ctx: ScanContext) -> Optional[str]:
        if not ctx.host:
            return None
        return f"{self.name}:host:{ctx.host.lower()}"


def _result_from_dict(provider_name: str, data: dict) -> IntelligenceResult:
    """Rehydrate a cached (JSON) provider result."""
    findings = []
    for f in data.get("findings", []):
        src = None
        s = f.get("source")
        if s:
            src = Source(
                name=s["name"],
                tier=SourceTier(int(s["tier"])),
                url=s.get("url", ""),
                retrieved_at=s.get("retrieved_at", ""),
            )
        findings.append(
            Finding(
                check_id=f["check_id"],
                title=f["title"],
                detail=f["detail"],
                evidence_class=EvidenceClass(f["evidence_class"]),
                points=f.get("points", 0),
                source=src,
                mitigating=f.get("mitigating", False),
            )
        )
    return IntelligenceResult(
        provider=data.get("provider", provider_name),
        findings=findings,
        available=data.get("available", True),
        note=data.get("note", ""),
    )
