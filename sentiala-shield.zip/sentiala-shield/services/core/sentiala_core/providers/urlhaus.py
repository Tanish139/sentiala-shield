"""URLhaus adapter — malware URL threat intelligence (abuse.ch).

Docs: https://urlhaus.abuse.ch/api/ — free, keyless, public.

A listing here is a VERIFIED FACT backed by a Tier 2 source (abuse.ch is
an established Swiss security research organisation). Sentiala only ever
*sends the hostname* to this API — never the full URL with paths or
credentials, never page content.
"""
from __future__ import annotations

from ..types import EvidenceClass, Finding, IntelligenceResult, ScanContext
from .base import Provider
from ..types import SourceTier


class URLhausProvider(Provider):
    name = "URLhaus (abuse.ch)"
    tier = SourceTier.TIER2
    description = "Community malware-URL feed operated by abuse.ch"
    source_url = "https://urlhaus.abuse.ch/"
    default_ttl = 1800  # listings are serious; re-check reasonably often

    def _query(self, ctx: ScanContext) -> IntelligenceResult:
        assert ctx.host
        resp = self.session.post(
            "https://urlhaus.abuse.ch/api/v1/host/",
            data={"host": ctx.host},
            timeout=self.timeout,
        )
        data = resp.json()
        status = data.get("query_status", "")

        if status == "no_results":
            return IntelligenceResult(
                provider=self.name,
                findings=[],
                note="host not present in URLhaus malware feed",
            )

        if status in ("ok", "found"):
            reference = data.get("urlhaus_reference") or data.get(
                "host_reference", ""
            )
            detail = (
                f"The host '{ctx.host}' is listed in the URLhaus malware "
                f"intelligence feed."
            )
            if reference:
                detail += f" Reference: {reference}"
            finding = Finding(
                check_id="intel_urlhaus_listing",
                title="Host listed on URLhaus malware feed",
                detail=detail,
                evidence_class=EvidenceClass.VERIFIED_FACT,
                points=45,
                source=self.source(),
            )
            return IntelligenceResult(
                provider=self.name, findings=[finding], note="host is listed"
            )

        # Unknown response shape — do not guess; report unavailability.
        return IntelligenceResult(
            provider=self.name,
            available=False,
            note=f"unexpected query_status: {str(status)[:80]!r}",
        )
