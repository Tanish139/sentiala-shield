"""DNS-over-HTTPS adapter (Cloudflare public resolvers, keyless).

Resolution data is an OBSERVATION about infrastructure. A domain that
does not resolve at all is a mild signal (typo, parked, or retired
phishing infrastructure); successful resolution is neutral and is not
treated as safety.
"""
from __future__ import annotations

from ..types import (
    EvidenceClass,
    Finding,
    IntelligenceResult,
    ScanContext,
    SourceTier,
)
from .base import Provider


class DnsOverHttpsProvider(Provider):
    name = "Cloudflare DNS-over-HTTPS"
    tier = SourceTier.TIER1
    description = "Authoritative DNS resolution check via Cloudflare DoH"
    source_url = "https://developers.cloudflare.com/1.1.1.1/"
    default_ttl = 900

    def _query(self, ctx: ScanContext) -> IntelligenceResult:
        assert ctx.host
        resp = self.session.get(
            "https://cloudflare-dns.com/dns-query",
            params={"name": ctx.host, "type": "A"},
            headers={"accept": "application/dns-json"},
            timeout=self.timeout,
        )
        data = resp.json()
        answers = data.get("Answer") or []

        if not answers:
            finding = Finding(
                check_id="dns_no_resolution",
                title="Domain does not resolve (NXDOMAIN / no A record)",
                detail=(
                    f"'{ctx.host}' currently has no A record. Common for "
                    f"typos, parked, or retired domains — an observation, "
                    f"not proof of maliciousness."
                ),
                evidence_class=EvidenceClass.OBSERVATION,
                points=6,
                source=self.source(),
            )
            return IntelligenceResult(provider=self.name, findings=[finding])

        # Resolution succeeded — record the neutral fact, no risk points.
        return IntelligenceResult(
            provider=self.name,
            findings=[],
            note=f"resolves ({len(answers)} A record(s))",
        )
