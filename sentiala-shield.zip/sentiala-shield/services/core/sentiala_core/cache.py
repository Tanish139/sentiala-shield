"""TTL cache for threat-intelligence lookups (Section 44).

Goals:
* reduce external API usage and respect provider limits,
* improve latency and reliability,
* optionally persist to disk so cached intelligence also powers offline mode.

Only provider responses are cached — never user content. Keys are
``provider:kind:value`` strings built from the public indicator being
looked up (host / domain), not from URLs with credentials or paths.
"""
from __future__ import annotations

import json
import os
import time
from typing import Any, Callable, Dict, Optional, Tuple


class TTLCache:
    def __init__(
        self,
        path: Optional[str] = None,
        default_ttl: int = 3600,
        clock: Callable[[], float] = time.time,
    ) -> None:
        self.path = path
        self.default_ttl = default_ttl
        self._clock = clock
        self._mem: Dict[str, Tuple[Any, float]] = {}
        if path and os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as fh:
                    raw = json.load(fh)
                self._mem = {k: (v["value"], v["expires_at"]) for k, v in raw.items()}
            except (OSError, ValueError, KeyError):
                # Corrupt cache files must never break scanning.
                self._mem = {}

    def get(self, key: str) -> Optional[Any]:
        entry = self._mem.get(key)
        if entry is None:
            return None
        value, expires_at = entry
        if self._clock() >= expires_at:
            self._mem.pop(key, None)
            return None
        return value

    def set(self, key: str, value: Any, ttl: Optional[int] = None) -> None:
        ttl = self.default_ttl if ttl is None else ttl
        self._mem[key] = (value, self._clock() + ttl)
        self._persist()

    def _persist(self) -> None:
        if not self.path:
            return
        try:
            os.makedirs(os.path.dirname(self.path), exist_ok=True)
            payload = {
                k: {"value": v[0], "expires_at": v[1]} for k, v in self._mem.items()
            }
            with open(self.path, "w", encoding="utf-8") as fh:
                json.dump(payload, fh)
        except OSError:
            # Persistence is best-effort; the in-memory cache still works.
            pass

    def __contains__(self, key: str) -> bool:
        return self.get(key) is not None

    def clear(self) -> None:
        self._mem.clear()
        if self.path and os.path.exists(self.path):
            try:
                os.remove(self.path)
            except OSError:
                pass
