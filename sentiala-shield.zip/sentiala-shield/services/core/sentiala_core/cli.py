"""Command-line interface for the Sentiala Shield core engine.

Usage:
    sentiala scan https://example.com
    sentiala scan paypa1-secure.tk --offline
    sentiala scan example.com --json --out report.md
    sentiala history --limit 5
    sentiala providers

Exit codes: 0 = no high verdict, 2 = HIGH RISK or CRITICAL verdict,
1 = usage/runtime error.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from typing import Optional, Sequence

from .orchestrator import SentialaCore, TOOL_PERMISSIONS
from .report import to_json, to_markdown

BANNER = r"""
  _____ _            _____ _     _      _    _  ___  _  __
 / ____| |          / ____| |   (_)    | |  | |/ / || |/ /
| (___ | |__  _   _| (___ | |__  _  ___| |__| / /| || ' /   S H I E L D
 \___ \| '_ \| | | |\___ \| '_ \| |/ __| '_ \/ / |__  | \
 ____) | | | | |_| |____) | | | | | (__| | | / /     | |\ \
|_____/|_| |_|\__, |_____/|_| |_|_|\___|_| |_/_/      |_| \_\
               __/ |
              |___/        AI-native defensive security
"""

LEVEL_COLOR = {
    "SAFE": "\033[92m",
    "LOW RISK": "\033[92m",
    "MEDIUM RISK": "\033[93m",
    "HIGH RISK": "\033[91m",
    "CRITICAL": "\033[91m",
}
RESET = "\033[0m"


def _supports_color() -> bool:
    return sys.stdout.isatty() and os.environ.get("NO_COLOR") is None


def render_console(report: dict) -> str:
    risk = report["risk"]
    level, score, conf = risk["level"], risk["score"], risk["confidence"]
    color = LEVEL_COLOR.get(level, "") if _supports_color() else ""
    reset = RESET if color else ""

    out = [BANNER]
    out.append("=" * 64)
    out.append(f"TARGET:      {report['target']}  ({report['target_kind']})")
    out.append(f"GENERATED:   {report['generated_at']} UTC")
    out.append("-" * 64)
    out.append(f"VERDICT:     {color}{level}{reset}")
    out.append(f"RISK SCORE:  {score}/100")
    out.append(f"CONFIDENCE:  {conf}%")
    out.append(f"INTEL:       {report['public_intelligence']}")
    out.append("=" * 64)
    out.append("")
    out.append("WHY (AI CORRELATION — rule-based in this phase):")
    for sentence in report["ai_explanation"].split(". "):
        sentence = sentence.strip()
        if not sentence:
            continue
        out.append(f"  • {sentence.rstrip('.')}.")
    out.append("")
    if report["contributions"]:
        out.append("EVIDENCE CONTRIBUTIONS:")
        for c in report["contributions"]:
            out.append(
                f"  +{c['points']:>2}  {c['title']}  "
                f"[{c['evidence_class']}] ({c['source']})"
            )
        out.append("")
    out.append("RECOMMENDED ACTION:")
    out.append(f"  {risk['recommended_action']}")
    out.append("")
    li = report["live_intelligence"]
    if li["offline_mode"]:
        out.append("⚠  OFFLINE MODE — live intelligence not consulted.")
    for d in li["degradations"]:
        out.append(f"⚠  {d}")
    if (not li["degradations"] and not li["offline_mode"]
            and li["providers"]
            and all(p["available"] for p in li["providers"])):
        out.append("All intelligence providers responded.")
    out.append("")
    out.append("Evidence classes: " + ", ".join(
        f"{cls}: {len(items)}"
        for cls, items in report["evidence"].items()
    ))
    out.append("")
    out.append(
        "Verdicts are evidence-based, not guaranteed. SAFE means "
        "'no significant evidence found'."
    )
    return "\n".join(out)


def _default_data_dir() -> str:
    env = os.environ.get("SENTIALA_DATA_DIR")
    if env:
        return env
    return os.path.join(os.path.expanduser("~"), ".sentiala")


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        prog="sentiala",
        description=(
            "Sentiala Shield core — evidence-based URL/domain security "
            "analysis with local-first processing."
        ),
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p_scan = sub.add_parser("scan", help="Scan a URL, domain, or IP")
    p_scan.add_argument("target", help="URL, domain, or IP to investigate")
    p_scan.add_argument(
        "--offline", action="store_true",
        help="Local rules only; skip all live intelligence",
    )
    p_scan.add_argument(
        "--json", action="store_true", help="Print the full JSON report",
    )
    p_scan.add_argument(
        "--out", metavar="PATH", help="Write the Markdown report to PATH",
    )
    p_scan.add_argument(
        "--data-dir", default=_default_data_dir(),
        help="Directory for local history and cache (default: ~/.sentiala)",
    )

    p_hist = sub.add_parser("history", help="Show local investigation history")
    p_hist.add_argument("--limit", type=int, default=20)
    p_hist.add_argument("--data-dir", default=_default_data_dir())

    sub.add_parser(
        "providers", help="List configured intelligence providers and tiers",
    )
    sub.add_parser(
        "permissions", help="Show the AI tool permission system",
    )

    args = parser.parse_args(argv)

    if args.command == "scan":
        core = SentialaCore(
            data_dir=args.data_dir, offline=args.offline
        )
        try:
            report = core.scan(args.target)
        except Exception as exc:  # noqa: BLE001
            print(f"error: scan failed: {exc}", file=sys.stderr)
            return 1
        if args.json:
            print(to_json(report))
        else:
            print(render_console(report))
        if args.out:
            with open(args.out, "w", encoding="utf-8") as fh:
                fh.write(to_markdown(report))
            print(f"\nMarkdown report written to {args.out}", file=sys.stderr)
        return 2 if report["risk"]["level"] in ("HIGH RISK", "CRITICAL") else 0

    if args.command == "history":
        core = SentialaCore(data_dir=args.data_dir)
        entries = core.history.latest(limit=args.limit)
        if not entries:
            print("No investigations recorded yet.")
            return 0
        print(f"{'WHEN (UTC)':<22}{'TARGET':<40}{'LEVEL':<12}{'SCORE':>6}  {'CONF':>5}")
        for e in entries:
            print(
                f"{str(e['timestamp']):<22}{str(e['target'])[:38]:<40}"
                f"{e['level']:<12}{e['risk_score']:>6}  {e['confidence']:>4}%"
            )
        return 0

    if args.command == "providers":
        core = SentialaCore(data_dir=_default_data_dir())
        print("Configured intelligence providers (SGIN adapters):")
        for p in core.providers:
            print(f"  [{int(p.tier)}] {p.name} — {p.description}")
        print(
            "\nKeyed providers (Google Safe Browsing, PhishTank, VirusTotal) "
            "are planned for Phase 4 and will read keys from the environment."
        )
        return 0

    if args.command == "permissions":
        print("SENTIALA TOOL PERMISSION SYSTEM")
        for tool, state in TOOL_PERMISSIONS.items():
            print(f"  {tool:<24} {state}")
        return 0

    return 1


if __name__ == "__main__":
    sys.exit(main())
