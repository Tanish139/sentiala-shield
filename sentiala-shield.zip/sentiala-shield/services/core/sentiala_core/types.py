"""Shared security types for Sentiala Shield.

Every conclusion produced by the pipeline is backed by typed, labelled
evidence. Two classifications are mandatory on every finding:

* ``EvidenceClass`` — VERIFIED FACT / OBSERVATION / AI INFERENCE /
  UNVERIFIED CLAIM (Section 20 of the product specification).
* ``Source`` with a reliability ``SourceTier`` (Sections 16-17).

Nothing in this module fabricates information; it only carries what
analysts and providers actually observed.
"""
from __future__ import annotations

import datetime as _dt
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


class EvidenceClass(str, Enum):
    """Fact vs inference taxonomy. Mandatory labelling (Section 20)."""

    VERIFIED_FACT = "VERIFIED FACT"      # directly supported by an external source
    OBSERVATION = "OBSERVATION"          # technically observed during analysis
    AI_INFERENCE = "AI INFERENCE"        # derived conclusion from multiple signals
    UNVERIFIED_CLAIM = "UNVERIFIED CLAIM"  # found online, not independently confirmed


class SourceTier(int, Enum):
    """Source reliability ranking (Section 16). Lower number == higher trust."""

    TIER1 = 1  # gov/CERT, official vendors, registry-operated protocol data, OWASP
    TIER2 = 2  # established security companies and research organisations
    TIER3 = 3  # community reports, forums, public discussions
    TIER4 = 4  # anonymous claims, low-quality aggregators

    @property
    def label(self) -> str:
        return {
            1: "Tier 1 (highest confidence)",
            2: "Tier 2 (trusted)",
            3: "Tier 3 (community)",
            4: "Tier 4 (unknown)",
        }[int(self)]


class RiskLevel(str, Enum):
    SAFE = "SAFE"
    LOW_RISK = "LOW RISK"
    MEDIUM_RISK = "MEDIUM RISK"
    HIGH_RISK = "HIGH RISK"
    CRITICAL = "CRITICAL"

    @property
    def badge(self) -> str:
        return {
            RiskLevel.SAFE: "[SAFE]",
            RiskLevel.LOW_RISK: "[LOW RISK]",
            RiskLevel.MEDIUM_RISK: "[MEDIUM RISK]",
            RiskLevel.HIGH_RISK: "[HIGH RISK]",
            RiskLevel.CRITICAL: "[CRITICAL]",
        }[self]


@dataclass
class Source:
    """Where a piece of evidence came from."""

    name: str
    tier: SourceTier
    url: str = ""
    retrieved_at: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "tier": int(self.tier),
            "tier_label": self.tier.label,
            "url": self.url,
            "retrieved_at": self.retrieved_at,
        }


@dataclass
class Finding:
    """A single piece of evidence produced by a deterministic check or provider.

    ``points`` is the finding's contribution to the risk score. Mitigating
    findings carry zero points and are surfaced as possible false-positive
    context instead.
    """

    check_id: str
    title: str
    detail: str
    evidence_class: EvidenceClass
    points: int = 0
    source: Optional[Source] = None
    mitigating: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "check_id": self.check_id,
            "title": self.title,
            "detail": self.detail,
            "evidence_class": self.evidence_class.value,
            "points": self.points,
            "source": self.source.to_dict() if self.source else None,
        }


@dataclass
class RiskAssessment:
    """Output of the risk engine (Layer 5). Fully explainable."""

    score: int
    level: RiskLevel
    confidence: int  # percent
    contributions: List[Dict[str, Any]] = field(default_factory=list)
    mitigating_factors: List[str] = field(default_factory=list)
    recommended_action: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "score": self.score,
            "level": self.level.value,
            "confidence": self.confidence,
            "contributions": self.contributions,
            "mitigating_factors": self.mitigating_factors,
            "recommended_action": self.recommended_action,
        }


@dataclass
class IntelligenceResult:
    """What one intelligence provider returned for a target.

    Providers never raise into the orchestrator; a failed lookup is
    reported as ``available=False`` with a ``note`` so the pipeline can
    degrade gracefully (offline mode, Section 45).
    """

    provider: str
    findings: List[Finding] = field(default_factory=list)
    available: bool = True
    note: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "provider": self.provider,
            "available": self.available,
            "note": self.note,
            "findings": [f.to_dict() for f in self.findings],
        }


@dataclass
class ScanContext:
    """Normalised description of what is being scanned."""

    target: str
    kind: str  # url | domain | ip | hash | unknown
    url: Optional[str] = None
    host: Optional[str] = None
    scheme_known: bool = True
