"""Investigation history — local JSONL store (Section 38).

Stored per record: target, timestamp, risk score/level, confidence, and
the number of evidence items. Storing full reports here is a deliberate
privacy choice: we keep enough to compare investigations over time
without hoarding page content. All data stays on the user's machine.
"""
from __future__ import annotations

import json
import os
from typing import Any, Dict, List, Optional


class History:
    def __init__(self, path: Optional[str] = None) -> None:
        self.path = path

    def append(self, entry: Dict[str, Any]) -> None:
        if not self.path:
            return
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        with open(self.path, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(entry, ensure_ascii=False) + "\n")

    def latest(self, limit: int = 20) -> List[Dict[str, Any]]:
        if not self.path or not os.path.exists(self.path):
            return []
        entries: List[Dict[str, Any]] = []
        with open(self.path, "r", encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    entries.append(json.loads(line))
                except ValueError:
                    continue  # skip corrupt lines, never crash history reads
        return list(reversed(entries[-limit:]))
