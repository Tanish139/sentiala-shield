"""Layer 4 — AI correlation (AI Provider abstraction, Section 42).

Sentiala deliberately does NOT let an LLM decide whether something is
malicious. The verdict comes from the deterministic risk engine. The AI
layer's job is *explanation*: turning structured evidence into a clear
narrative and separating fact from inference.

This module ships the ``LocalCorrelator`` — a fully deterministic,
offline, rule-based narrative generator. It is a real, tested component
(not a mock): given the same evidence it always produces the same text,
it never invents indicators, and it only ever restates findings that
exist in the report.

Cloud LLM providers (Sarvam, local models) plug in through
``AIProvider`` in Phase 3. They will receive the *structured evidence
only* — never user credentials, cookies, or private data — and their
output will always be labelled AI INFERENCE, never fact.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import List

from .types import EvidenceClass, Finding, RiskAssessment, RiskLevel


class AIProvider(ABC):
    """Interface for correlation/explanation backends."""

    name: str = "ai-provider"

    @abstractmethod
    def explain(self, target: str, assessment: RiskAssessment,
               findings: List[Finding]) -> str:
        ...


class LocalCorrelator(AIProvider):
    """Deterministic narrative generator (default; offline-capable)."""

    name = "Sentiala Local Correlator (deterministic)"

    def explain(self, target: str, assessment: RiskAssessment,
               findings: List[Finding]) -> str:
        parts: list[str] = []
        level = assessment.level
        score = assessment.score

        if score == 0:
            verified_seen = any(
                f.evidence_class == EvidenceClass.VERIFIED_FACT
                for f in findings
            )
            parts.append(
                f"Sentiala found no contributing risk indicators for "
                f"'{target}'."
            )
            if verified_seen:
                parts.append(
                    "External intelligence sources were consulted and "
                    "returned no matches for this target."
                )
            parts.append(
                "Absence of evidence is not proof of safety — this verdict "
                "means 'no significant evidence found', not 'verified safe'."
            )
            return " ".join(parts)

        parts.append(
            f"Sentiala assessed '{target}' as {level.value} (risk score "
            f"{score}/100) by correlating the following evidence:"
        )
        for c in assessment.contributions[:5]:
            parts.append(
                f"• {c['title']} (+{c['points']} points, {c['evidence_class']}, "
                f"source: {c['source']})."
            )
        if len(assessment.contributions) > 5:
            parts.append(
                f"…and {len(assessment.contributions) - 5} further indicator(s) "
                f"listed in the evidence section."
            )

        verified = [
            c for c in assessment.contributions
            if c["evidence_class"] == EvidenceClass.VERIFIED_FACT.value
        ]
        if verified:
            parts.append(
                f"Of these, {len(verified)} finding(s) are verified facts "
                f"confirmed by external sources; the remainder are "
                f"deterministic observations from URL structure and "
                f"infrastructure analysis."
            )
        else:
            parts.append(
                "All contributing indicators are deterministic observations "
                "or inferences — no external source has (yet) confirmed "
                "malicious activity for this target."
            )
        if level in (RiskLevel.HIGH_RISK, RiskLevel.CRITICAL):
            parts.append(
                "The high verdict reflects the combination of multiple "
                "independent indicators rather than any single signal."
            )
        parts.append(
            "This explanation is a rule-based correlation of the evidence "
            "above, produced by Sentiala's local deterministic correlator."
        )
        return " ".join(parts)
