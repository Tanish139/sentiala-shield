"""Layer 5 — explainable risk engine (Sections 5, 60).

The engine aggregates weighted findings. Design rules:

1. **No single deterministic signal can produce a CRITICAL verdict.**
   Only multiple independent indicators (or a verified threat-intel
   match combined with structural indicators) reach the highest bands.
2. Brand-impersonation family checks (homograph, typosquat, brand in
   subdomain) describe the *same underlying suspicion*, so only the
   strongest of them is counted, never their sum.
3. Every point in the score maps to a named contribution the user can
   inspect — nothing is hidden inside a black box.
4. Confidence measures *how well-evidenced the assessment is*, not how
   bad the target is. Offline assessments lose confidence explicitly.

Weight table (points per check):

==============================  =====
check_id                        points
==============================  =====
intel_urlhaus_listing            45
dangerous_scheme                 60
homograph_domain                 35
typosquatting                    30/20 (edit distance 1/2)
credentials_in_url               30
ip_literal_host                  22
brand_in_subdomain               22
rdap_young_domain                15
suspicious_tld                   12
suspicious_keywords               8/12
no_https                          8
nonstandard_port                  8
many_subdomains                   6
excessive_hyphens                 6
dns_no_resolution                 6
rdap_not_found                    6
long_url                          3
url_shortener                     3
==============================  =====

Verdict bands: 0-4 SAFE, 5-19 LOW RISK, 20-49 MEDIUM RISK, 50-79 HIGH
RISK, 80+ CRITICAL.
"""
from __future__ import annotations

from typing import List

from .types import (
    EvidenceClass,
    Finding,
    RiskAssessment,
    RiskLevel,
    SourceTier,
)

#: Checks describing the same underlying suspicion — only the strongest counts.
IMPERSONATION_FAMILY = {"homograph_domain", "typosquatting", "brand_in_subdomain"}

RECOMMENDED_ACTION = {
    RiskLevel.SAFE: (
        "No significant evidence of danger was found. Normal browsing "
        "caution still applies."
    ),
    RiskLevel.LOW_RISK: (
        "Minor suspicious indicators were noticed. Proceed, but avoid "
        "entering sensitive credentials unless you expected this site."
    ),
    RiskLevel.MEDIUM_RISK: (
        "Multiple suspicious indicators. Review the evidence below before "
        "entering credentials, payment details, or personal information."
    ),
    RiskLevel.HIGH_RISK: (
        "Strong evidence of malicious activity. Do not enter credentials "
        "or download files; close the site and reach the service through "
        "its official domain instead."
    ),
    RiskLevel.CRITICAL: (
        "Strong evidence of immediate danger. Leave immediately, do not "
        "enter credentials or download anything, and scan the device if "
        "you already interacted with this target."
    ),
}


def _level_for(score: int) -> RiskLevel:
    if score >= 80:
        return RiskLevel.CRITICAL
    if score >= 50:
        return RiskLevel.HIGH_RISK
    if score >= 20:
        return RiskLevel.MEDIUM_RISK
    if score >= 5:
        return RiskLevel.LOW_RISK
    return RiskLevel.SAFE


def assess(
    findings: List[Finding], live_intel_available: bool = True
) -> RiskAssessment:
    contributing = sorted(
        (f for f in findings if f.points > 0 and not f.mitigating),
        key=lambda f: (-f.points, f.check_id),
    )
    mitigations = [f for f in findings if f.mitigating]

    family = [f for f in contributing if f.check_id in IMPERSONATION_FAMILY]
    others = [f for f in contributing if f.check_id not in IMPERSONATION_FAMILY]
    family_points = max((f.points for f in family), default=0)
    score = min(100, family_points + sum(f.points for f in others))

    level = _level_for(score)

    verified = [
        f for f in contributing if f.evidence_class == EvidenceClass.VERIFIED_FACT
    ]
    high_tier = [
        f for f in verified if f.source and f.source.tier in
        (SourceTier.TIER1, SourceTier.TIER2)
    ]
    distinct_checks = len({f.check_id for f in contributing})

    if score == 0:
        # Clean verdict: confidence comes from corroboration, not severity.
        confidence = 70
        if live_intel_available:
            confidence += 10
        if mitigations:
            confidence += min(len(mitigations), 3) * 5
    else:
        confidence = 55
        confidence += 8 * min(distinct_checks, 3)
        if verified:
            confidence += 10
        if len(high_tier) >= 2:
            confidence += 10
    if not live_intel_available:
        confidence -= 20
    confidence = max(30, min(97, int(confidence)))

    contributions = [
        {
            "check_id": f.check_id,
            "title": f.title,
            "points": f.points,
            "evidence_class": f.evidence_class.value,
            "source": f.source.name if f.source else "Sentiala local rules",
        }
        for f in contributing
    ]
    mitigating_factors = [
        f"{f.title} — {f.detail}" for f in mitigations
    ] or [
        "No mitigating factors observed for this target."
    ]

    return RiskAssessment(
        score=score,
        level=level,
        confidence=confidence,
        contributions=contributions,
        mitigating_factors=mitigating_factors,
        recommended_action=RECOMMENDED_ACTION[level],
    )
