"""Sentiala Shield core engine — Phase 1-6 vertical slice."""
from .ai import AIProvider, LocalCorrelator
from .cache import TTLCache
from .history import History
from .orchestrator import SentialaCore, classify_target
from .providers import (
    DnsOverHttpsProvider,
    Provider,
    RdapProvider,
    URLhausProvider,
)
from .risk_engine import assess
from .types import (
    EvidenceClass,
    Finding,
    IntelligenceResult,
    RiskAssessment,
    RiskLevel,
    ScanContext,
    Source,
    SourceTier,
)
from .url_analyzer import analyze_url

__version__ = "0.1.0"

__all__ = [
    "SentialaCore",
    "classify_target",
    "analyze_url",
    "assess",
    "TTLCache",
    "History",
    "AIProvider",
    "LocalCorrelator",
    "Provider",
    "URLhausProvider",
    "RdapProvider",
    "DnsOverHttpsProvider",
    "EvidenceClass",
    "Finding",
    "IntelligenceResult",
    "RiskAssessment",
    "RiskLevel",
    "ScanContext",
    "Source",
    "SourceTier",
    "__version__",
]
