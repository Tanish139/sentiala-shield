"""Layer 1 — deterministic URL / domain analysis (Sections 5, 7, 8).

This module never fetches the target and never calls an LLM. It performs
reproducible structural checks on the URL itself:

* scheme safety (https, dangerous schemes like data:/javascript:)
* embedded userinfo (user:password@host obfuscation)
* raw IP literal hosts
* punycode / IDN homograph attacks against a curated brand list
* typosquatting (edit distance) against the same brand list
* brand names embedded in subdomains of unrelated domains
* suspicious TLDs, deep subdomains, hyphen stuffing, shorteners,
  credential-harvesting keywords, non-standard ports

Every check emits a ``Finding`` with an explicit risk contribution and is
labelled OBSERVATION — these are technical observations, not verified
facts about maliciousness.
"""
from __future__ import annotations

import ipaddress
import re
import unicodedata
from urllib.parse import unquote, urlparse

from .types import EvidenceClass, Finding, Source, SourceTier

LOCAL_SOURCE = Source(
    name="Sentiala local deterministic rules",
    tier=SourceTier.TIER1,
    url="local://deterministic-url-analyzer",
)

#: Curated brand -> legitimate registered domain map used for
#: typosquatting / homograph / brand-impersonation checks.
BRANDS: dict[str, str] = {
    "google": "google.com",
    "youtube": "youtube.com",
    "gmail": "gmail.com",
    "microsoft": "microsoft.com",
    "outlook": "outlook.com",
    "office": "office.com",
    "onedrive": "onedrive.com",
    "apple": "apple.com",
    "icloud": "icloud.com",
    "amazon": "amazon.com",
    "netflix": "netflix.com",
    "facebook": "facebook.com",
    "instagram": "instagram.com",
    "whatsapp": "whatsapp.com",
    "linkedin": "linkedin.com",
    "twitter": "twitter.com",
    "x": "x.com",
    "dropbox": "dropbox.com",
    "adobe": "adobe.com",
    "dhl": "dhl.com",
    "fedex": "fedex.com",
    "ups": "ups.com",
    "usps": "usps.com",
    "hsbc": "hsbc.com",
    "chase": "chase.com",
    "wellsfargo": "wellsfargo.com",
    "americanexpress": "americanexpress.com",
    "barclays": "barclays.com",
    "paypal": "paypal.com",
    "steam": "steampowered.com",
    "discord": "discord.com",
    "roblox": "roblox.com",
    "telegram": "telegram.org",
    "hdfcbank": "hdfcbank.com",
    "icicibank": "icicibank.com",
    "sbi": "sbi.co.in",
    "axisbank": "axisbank.com",
    "kotak": "kotak.com",
    "paytm": "paytm.com",
    "phonepe": "phonepe.com",
    "razorpay": "razorpay.com",
    "flipkart": "flipkart.com",
    "irctc": "irctc.co.in",
    "airtel": "airtel.in",
    "jio": "jio.com",
    "bsnl": "bsnl.co.in",
}

MULTI_PART_TLDS = {
    "co.uk", "org.uk", "ac.uk", "gov.uk",
    "co.in", "net.in", "org.in", "ac.in", "gov.in", "edu.in", "res.in",
    "com.au", "net.au", "co.nz", "co.za", "com.br", "com.mx",
    "com.cn", "co.jp", "com.sg", "com.tr",
}

#: Weakly correlated with abuse in phishing research; always a *weak*
#: signal on its own and stated as such in the finding detail.
SUSPICIOUS_TLDS = {
    "zip", "mov", "tk", "ml", "ga", "cf", "gq", "top", "click", "cam",
    "work", "bar", "rest", "country", "stream", "download", "loan",
    "review", "icu",
}

URL_SHORTENERS = {
    "bit.ly", "t.co", "tinyurl.com", "is.gd", "cutt.ly", "rb.gy",
    "shorturl.at", "rebrand.ly", "tiny.cc", "ow.ly", "buff.ly",
    "goo.gl", "t.ly", "s.id", "shorte.st", "lnkd.in",
}

KEYWORD_RE = re.compile(
    r"\b(login|signin|sign-in|verify|verification|secure|account|"
    r"update|confirm|password|banking|invoice|payment|refund|wallet|"
    r"otp|webmail|recover|unlock|suspended|limited|authenticate|"
    r"credential|kyc)\b",
    re.IGNORECASE,
)

DANGEROUS_SCHEMES = {"data", "javascript", "vbscript", "file"}

# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

_CONFUSABLE_MAP = str.maketrans(
    {
        # Cyrillic confusables
        "а": "a", "е": "e", "о": "o", "р": "p", "с": "c", "х": "x",
        "у": "y", "ѕ": "s", "і": "i", "ј": "j", "һ": "h", "ԁ": "d",
        # Greek confusables
        "α": "a", "ο": "o", "τ": "t", "ρ": "p", "κ": "k", "ν": "v",
        "ϵ": "e", "ς": "s",
        # leet-style substitutions (used only for visual-similarity checks)
        "0": "o", "1": "l", "3": "e", "4": "a", "5": "s", "7": "t",
        "8": "b", "@": "a", "$": "s",
    }
)


def confusable_normalize(text: str) -> str:
    """Fold unicode confusables to ASCII for visual-similarity comparison.

    NFKD + combining-mark removal handles accented Latin (e.g. ``ä`` -> ``a``);
    an explicit Cyrillic/Greek map handles cross-script homoglyphs.
    """
    text = unicodedata.normalize("NFKD", text)
    text = "".join(c for c in text if not unicodedata.combining(c))
    text = text.translate(_CONFUSABLE_MAP)
    text = "".join(c for c in text if ord(c) < 128)
    return text.lower()


def punycode_decode(host: str) -> str | None:
    """Decode IDN (xn--) labels. Returns None if the host is malformed."""
    labels = host.split(".")
    try:
        return ".".join(
            lbl.encode("ascii").decode("idna") if lbl.lower().startswith("xn--")
            else lbl
            for lbl in labels
        )
    except (UnicodeError, ValueError):
        return None


def levenshtein(a: str, b: str) -> int:
    if a == b:
        return 0
    if not a or not b:
        return max(len(a), len(b))
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]


def split_host(host: str) -> tuple[str, str, str]:
    """Split a host into (subdomain, sld, tld) using a small suffix table."""
    host = host.lower().rstrip(".")
    labels = host.split(".")
    if len(labels) == 1:
        return "", labels[0], ""
    if len(labels) >= 3 and ".".join(labels[-2:]) in MULTI_PART_TLDS:
        return ".".join(labels[:-3]), labels[-3], ".".join(labels[-2:])
    return ".".join(labels[:-2]), labels[-2], labels[-1]


def is_brand_legit_host(host: str) -> str | None:
    """Return the brand name if ``host`` is the brand's own domain or a
    subdomain of it (e.g. www.paypal.com)."""
    sub, sld, tld = split_host(host)
    if not tld:
        return None
    registered = f"{sld}.{tld}"
    for brand, legit in BRANDS.items():
        if registered == legit or (sub and sub.endswith("." + legit)):
            return brand
    return None


# ---------------------------------------------------------------------------
# analyzer
# ---------------------------------------------------------------------------

def analyze_url(url: str, scheme_known: bool = True) -> list[Finding]:
    """Run all deterministic checks. Never raises on malformed input."""
    findings: list[Finding] = []
    try:
        parsed = urlparse(url)
        host = (parsed.hostname or "").lower()
    except ValueError:
        host = ""

    scheme = (parsed.scheme or "").lower()

    # -- scheme (dangerous schemes matter even without a host) ---------
    if scheme_known and scheme in DANGEROUS_SCHEMES:
        findings.append(
            Finding(
                check_id="dangerous_scheme",
                title=f"Dangerous URI scheme: {scheme}:",
                detail=(
                    f"The '{scheme}:' scheme can execute or embed content "
                    f"directly (e.g. javascript:, data:) and is a known "
                    f"phishing vector. Sentiala never fetches such URLs."
                ),
                evidence_class=EvidenceClass.OBSERVATION,
                points=60,
                source=LOCAL_SOURCE,
            )
        )
        return findings  # nothing else about this 'URL' is meaningful

    if not host:
        findings.append(
            Finding(
                check_id="unparseable_url",
                title="URL could not be parsed",
                detail=f"'{url[:120]}' has no usable hostname; it may be malformed.",
                evidence_class=EvidenceClass.OBSERVATION,
                points=10,
                source=LOCAL_SOURCE,
            )
        )
        return findings

    sub, sld, tld = split_host(host)
    registered = f"{sld}.{tld}" if tld else sld

    def add(check_id: str, title: str, detail: str, points: int,
            mitigating: bool = False) -> None:
        findings.append(
            Finding(
                check_id=check_id,
                title=title,
                detail=detail,
                evidence_class=EvidenceClass.OBSERVATION,
                points=points,
                source=LOCAL_SOURCE,
                mitigating=mitigating,
            )
        )

    # -- scheme ------------------------------------------------------------
    if scheme_known:
        if scheme == "https":
            add(
                "https",
                "Connection encrypted (HTTPS)",
                "The target uses HTTPS. Note: HTTPS proves transport "
                "encryption only — phishing sites use valid HTTPS too.",
                0,
                mitigating=True,
            )
        else:
            add(
                "no_https",
                "No transport encryption (not HTTPS)",
                "Credentials or data submitted to this target would travel "
                "in cleartext.",
                8,
            )

    # -- embedded userinfo ---------------------------------------------------
    if parsed.username or parsed.password:
        add(
            "credentials_in_url",
            "Userinfo embedded in URL",
            "The URL contains 'user:password@host' syntax. Attackers use "
            "this to obscure the real host behind a familiar-looking prefix.",
            30,
        )

    # -- raw IP host ---------------------------------------------------------
    try:
        ipaddress.ip_address(host)
    except ValueError:
        pass
    else:
        add(
            "ip_literal_host",
            "Raw IP address used as host",
            "The link points at a bare IP address instead of a domain name, "
            "which is common for disposable phishing/malware infrastructure.",
            22,
        )

    # -- IDN / homograph ------------------------------------------------------
    homograph_hit = None
    if any(lbl.lower().startswith("xn--") for lbl in host.split(".")):
        decoded = punycode_decode(host)
        if decoded is None:
            add(
                "invalid_idn",
                "Malformed internationalised domain",
                "The host contains an xn-- label that fails IDNA decoding.",
                15,
            )
        else:
            norm_registered = ".".join(confusable_normalize(decoded).split(".")[-2:])
            for brand, legit in BRANDS.items():
                if norm_registered == legit and registered != legit:
                    homograph_hit = (brand, legit, decoded)
                    break
    elif any(ord(c) > 127 for c in host):
        norm_registered = ".".join(confusable_normalize(host).split(".")[-2:])
        for brand, legit in BRANDS.items():
            if norm_registered == legit and registered != legit:
                homograph_hit = (brand, legit, host)
                break

    brand_owner = is_brand_legit_host(host)

    if homograph_hit:
        brand, legit, decoded = homograph_hit
        add(
            "homograph_domain",
            f"Homograph domain imitating '{legit}'",
            f"The internationalised domain '{decoded}' is visually near-identical "
            f"to the legitimate '{legit}'. This is a classic homograph attack.",
            35,
        )

    # -- typosquatting ----------------------------------------------------------
    if not homograph_hit and brand_owner is None:
        best_brand, best_dist = None, 99
        for brand in BRANDS:
            if sld == brand:
                continue
            # Short names (either side) produce meaningless edit distances:
            # e.g. 'bbc' is distance 2 from 'hsbc' by pure brevity.
            if len(brand) < 5 or len(sld) < 5:
                continue
            d = levenshtein(sld, brand)
            if d < best_dist:
                best_brand, best_dist = brand, d
        if best_brand is not None and best_dist in (1, 2):
            points = 30 if best_dist == 1 else 20
            add(
                "typosquatting",
                f"Possible typosquat of '{BRANDS[best_brand]}'",
                f"The domain '{registered}' is edit-distance {best_dist} from "
                f"the brand '{best_brand}' (legitimate: {BRANDS[best_brand]}). "
                f"This is a common typosquatting pattern.",
                points,
            )

    # -- brand embedded in subdomain ---------------------------------------------
    if brand_owner is None:
        sub_labels = [lbl for lbl in sub.split(".") if lbl]
        for brand, legit in BRANDS.items():
            if brand in sub_labels:
                add(
                    "brand_in_subdomain",
                    f"Brand name '{brand}' embedded in subdomain",
                    f"The label '{brand}' appears in the subdomain while the "
                    f"registered domain is '{registered}' — not '{legit}'. "
                    f"Phishers embed brand names in subdomains to look legitimate.",
                    22,
                )
                break

    # -- TLD reputation (weak signal) ----------------------------------------------
    if tld in SUSPICIOUS_TLDS:
        add(
            "suspicious_tld",
            f"Top-level domain '.{tld}' has elevated abuse rates",
            f"'.{tld}' is frequently associated with phishing and disposable "
            f"infrastructure. This is a weak signal on its own and can be a "
            f"false positive for legitimate sites.",
            12,
        )

    # -- structural oddities -----------------------------------------------------
    if tld and registered in URL_SHORTENERS:
        add(
            "url_shortener",
            "URL shortener",
            "Shortened links hide their true destination; the final target "
            "should be expanded before trusting it.",
            3,
        )

    sub_count = len([l for l in sub.split(".") if l])
    if sub_count >= 4:
        add(
            "many_subdomains",
            f"Unusually deep subdomain chain ({sub_count} labels)",
            "Long subdomain chains are used to push the real domain out of "
            "view on small screens.",
            6,
        )

    if host.count("-") >= 3:
        add(
            "excessive_hyphens",
            "Many hyphens in host name",
            f"'{host}' contains {host.count('-')} hyphens, typical of "
            f"generated phishing domains.",
            6,
        )

    # -- credential-harvesting keywords in path/query --------------------------------
    # (skipped when the host IS a brand's own domain — a brand's real
    # login page naturally contains these words)
    if brand_owner is None:
        surface = unquote(f"{parsed.path or ''} {parsed.query or ''}").lower()
        keyword_hits = sorted(set(KEYWORD_RE.findall(surface))) if surface else []
        if keyword_hits:
            points = 8 if len(keyword_hits) <= 2 else 12
            add(
                "suspicious_keywords",
                "Credential-harvesting keywords in path",
                f"Path/query contains: {', '.join(keyword_hits)}. These words are "
                f"common in phishing page paths but also occur on legitimate "
                f"login pages — weigh together with other evidence.",
                points,
            )

    if len(url) > 100:
        add(
            "long_url",
            "Unusually long URL",
            f"URL length is {len(url)} characters; long URLs can conceal "
            f"redirect parameters.",
            3,
        )

    try:
        port = parsed.port
    except ValueError:
        port = -1
    if port not in (None, 80, 443):
        add(
            "nonstandard_port",
            f"Non-standard port :{port}",
            "The URL targets a non-standard port, sometimes used to host "
            "phishing panels on compromised machines.",
            8,
        )

    return findings
