"""End-to-end demo of the Sentiala Shield core pipeline.

Runs the FULL online pipeline (all three intelligence providers) against
recorded synthetic responses, so the complete flow — deterministic
analysis, threat intelligence, risk engine, AI correlation, reporting —
can be demonstrated with no network access and no real hosts.

The recorded responses use reserved `.test` domains only. Nothing here
is fabricated intelligence about real hosts: the "listed host" case is a
synthetic reserved domain, and the demo says so.

Usage:
    python scripts/demo.py [output_dir]
"""
from __future__ import annotations

import json
import os
import sys
import tempfile

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..",
                                "services", "core"))

from sentiala_core.orchestrator import SentialaCore          # noqa: E402
from sentiala_core.report import to_json, to_markdown         # noqa: E402
from sentiala_core.cli import render_console                  # noqa: E402


class FakeResponse:
    def __init__(self, status_code=200, payload=None):
        self.status_code = status_code
        self._payload = payload

    def json(self):
        return self._payload


class RecordedSession:
    """Replays the same recorded responses used by the test suite."""

    def __init__(self, scenario: str):
        fx = os.path.join(os.path.dirname(__file__), "..", "tests",
                          "fixtures")
        with open(os.path.join(fx, f"urlhaus_{scenario}.json")) as fh:
            urlhaus = json.load(fh)
        with open(os.path.join(fx, "rdap_established.json")) as fh:
            rdap_est = json.load(fh)
        with open(os.path.join(fx, "rdap_young.json")) as fh:
            rdap_young = json.load(fh)
        with open(os.path.join(fx, "doh_answer.json")) as fh:
            doh = json.load(fh)

        self.routes = [
            ("POST", "urlhaus.abuse.ch",
             FakeResponse(200, urlhaus)),
            ("GET", "rdap.org",
             FakeResponse(200, rdap_young if scenario == "listed"
                          else rdap_est)),
            ("GET", "cloudflare-dns.com", FakeResponse(200, doh)),
        ]

    def _match(self, method, url):
        for m, needle, resp in self.routes:
            if m == method and needle in url:
                return resp
        raise ConnectionError(f"no recorded route for {method} {url}")

    def get(self, url, **kw):
        return self._match("GET", url)

    def post(self, url, **kw):
        return self._match("POST", url)


def run(target: str, scenario: str, out_dir: str, stem: str) -> dict:
    with tempfile.TemporaryDirectory() as data_dir:
        core = SentialaCore(data_dir=data_dir,
                            session=RecordedSession(scenario))
        report = core.scan(target)

    print(render_console(report))
    print("\n" + "=" * 64 + "\n")

    with open(os.path.join(out_dir, f"{stem}.md"), "w",
              encoding="utf-8") as fh:
        fh.write(to_markdown(report))
    with open(os.path.join(out_dir, f"{stem}.json"), "w",
              encoding="utf-8") as fh:
        fh.write(to_json(report))
    return report


def main() -> None:
    out_dir = sys.argv[1] if len(sys.argv) > 1 else tempfile.mkdtemp()
    os.makedirs(out_dir, exist_ok=True)

    print("#" * 64)
    print("# DEMO 1 — clean target, all providers responsive")
    print("# (recorded responses; synthetic .test domains)")
    print("#" * 64 + "\n")
    run("https://old-faithful.test/", "no_results", out_dir,
        "sample-report-clean-target")

    print("#" * 64)
    print("# DEMO 2 — host listed on URLhaus + newly registered domain")
    print("# (recorded responses; synthetic .test domain)")
    print("#" * 64 + "\n")
    run("http://malicious.test/download", "listed", out_dir,
        "sample-report-high-risk")

    print(f"Reports written to {out_dir}/")


if __name__ == "__main__":
    main()
