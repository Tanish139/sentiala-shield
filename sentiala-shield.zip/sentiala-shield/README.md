<div align="center">

# Sentiala Shield

**An AI-native cybersecurity platform that combines browser protection, threat intelligence, public security research, phishing detection, privacy protection, and evidence-based AI investigation into one unified security system.**

Defensive security only · Local-first · Evidence-based · No fabricated intelligence

</div>

---

## What this is (honestly)

Sentiala Shield is being built as an **AI security analyst** that helps protect your computer, browsing, and digital interactions, and can run deep, evidence-based investigations across legitimate public information sources.

This repository currently contains **Phases 1–6 of the [roadmap](#roadmap)**: the full **Sentiala Intelligence Core** — a working, tested URL/domain investigation pipeline with deterministic analysis, live threat intelligence from free public sources, an explainable risk engine, and evidence-based reporting. The browser extension, desktop agent, and dashboard are scaffolded and planned (see `docs/ARCHITECTURE.md`).

What Sentiala is **not**:

- Not a fake antivirus. Every verdict is derived from named, inspectable evidence.
- Not a guarantee. `SAFE` means *"no significant evidence found"* — not *"verified safe"*. Sentiala cannot detect every threat, and it says so in every report.
- Not spyware. Sentiala is a **defensive** product: no credential access, no keylogging, no cookie theft, no covert surveillance, no unauthorized remote access, no persistence tricks. See [SECURITY.md](SECURITY.md) and the permission system (`sentiala permissions`).

## The six-layer analysis model

A single LLM never decides whether something is malicious. Every scan flows through six layers:

```
        ┌────────────────────────────────────────────────┐
        │              SENTIALA INTELLIGENCE CORE         │
        │                                                │
target ─┤ 1. DETERMINISTIC ANALYSIS                      │
        │    URL structure · HTTPS · IDN/homograph ·      │
        │    typosquatting · brands · TLDs · keywords     │
        │                                                │
        │ 2. THREAT INTELLIGENCE  (SGIN adapters)         │
        │    URLhaus · RDAP registry data · DNS (DoH)     │
        │    cached, keyless, provider-swappable          │
        │                                                │
        │ 3. PUBLIC WEB INTELLIGENCE   (Phase 5)          │
        │                                                │
        │ 4. AI CORRELATION                               │
        │    deterministic LocalCorrelator (cloud LLM     │
        │    via AIProvider in Phase 3)                   │
        │                                                │
        │ 5. RISK ENGINE                                 │
        │    weighted, explainable, family-suppressed      │
        │    SAFE → LOW → MEDIUM → HIGH → CRITICAL        │
        │                                                │
        │ 6. EXPLAINABILITY                               │
        │    VERIFIED FACT · OBSERVATION · AI INFERENCE   │
        │    UNVERIFIED CLAIM — every report, every time  │
        └────────────────────────────────────────────────┘
```

If evidence does not exist, the report says **`NO RELEVANT PUBLIC INTELLIGENCE FOUND`** — never invented intelligence, never invented CVEs, never invented researchers.

## Quick start

```bash
git clone <this-repo> sentiala-shield
cd sentiala-shield

# no install needed to test the suite
pip install pytest requests
pytest                    # 68 tests

# install the CLI
pip install .             # or: pip install -e .
```

```text
$ sentiala scan https://example.com/

  ... banner ...

================================================================
TARGET:      https://example.com/  (url)
VERDICT:     SAFE
RISK SCORE:  0/100
CONFIDENCE:  85%
INTEL:       NO RELEVANT PUBLIC INTELLIGENCE FOUND
================================================================
WHY (AI CORRELATION — rule-based in this phase):
  • Sentiala found no contributing risk indicators for 'https://example.com/'.
  • External intelligence sources were consulted and returned no matches ...
RECOMMENDED ACTION:
  No significant evidence of danger was found. Normal browsing caution still applies.

All intelligence providers responded.
```

Investigate a phishing-style target (offline, deterministic layer only):

```text
$ sentiala scan http://paypal.com.verify-account.xyz/login --offline
VERDICT:     MEDIUM RISK
RISK SCORE:  30/100   (brand_in_subdomain +22, suspicious_keywords +8)
```

Save the full evidence report:

```bash
sentiala scan example.com --out report.md      # Markdown report
sentiala scan example.com --json               # structured JSON
```

Other commands:

```bash
sentiala history --limit 10    # local investigation history
sentiala providers             # intelligence sources + reliability tiers
sentiala permissions           # AI tool permission system
```

Exit codes: `0` normal · `2` HIGH RISK / CRITICAL verdict · `1` error.

## What the reports contain

Every investigation (JSON + Markdown) includes, per the product spec:

- **Risk score, level, confidence** — confidence is *evidence quality*, not severity; offline scans lose confidence explicitly.
- **Evidence in four classes** — `VERIFIED FACT` (external source confirmed it), `OBSERVATION` (technically observed), `AI INFERENCE` (derived conclusion), `UNVERIFIED CLAIM` (found online, unconfirmed).
- **Every contribution to the score** — check id, points, evidence class, source.
- **Possible false positives** — mitigating factors (HTTPS present, long domain history, …) are surfaced, not hidden.
- **Source reliability tiers** — Tier 1 (registry/protocol data) … Tier 4 (unverified).
- **Recommended action** and an honest disclaimer.

## Privacy model

- **Local-first.** The URL analyzer runs entirely offline; nothing leaves the machine.
- **Minimal disclosure.** When live intelligence is consulted, providers receive **only the hostname** of the indicator — never full URLs with credentials, never page content, never your data.
- **Local storage.** History and intelligence cache live in `~/.sentiala` (or `SENTIALA_DATA_DIR`) and can be deleted at any time. No telemetry, no accounts.
- **Offline mode.** `--offline` (or `SENTIALA_OFFLINE=true`) disables all network intelligence; the report states this and lowers confidence.
- **Never sent anywhere:** passwords, cookies, tokens, private keys, private messages, personal files. The permission system denies these at the architecture level.

## Intelligence sources (current)

| Source | What it provides | Tier | Key required |
|---|---|---|---|
| Sentiala deterministic rules | URL/domain structure analysis | 1 (local) | no |
| RDAP (rdap.org bootstrap) | domain registration age, registrar | 1 | no |
| Cloudflare DNS-over-HTTPS | resolution status | 1 | no |
| URLhaus (abuse.ch) | malware-URL host listings | 2 | no |

Providers are adapters behind a `Provider` interface — if one is unreachable, the scan continues and the report records the degradation. Keyed sources (Google Safe Browsing, PhishTank, VirusTotal) are planned for Phase 4 via `.env` only; keys are never committed and never embedded in any client (including the future browser extension).

## Repository layout

```text
sentiala-shield/
├── apps/                      # Phase 7-9 targets (scaffolds, documented)
│   ├── browser-extension/
│   ├── desktop-agent/
│   └── dashboard/
├── services/
│   └── core/                  # THE ENGINE (this is real, tested code)
│       └── sentiala_core/
│           ├── url_analyzer.py      # Layer 1: deterministic analysis
│           ├── providers/           # Layer 2: threat intel adapters
│           │   ├── base.py         #   provider abstraction + caching
│           │   ├── urlhaus.py
│           │   ├── rdap.py
│           │   └── doh.py
│           ├── ai.py                # Layer 4: AIProvider + LocalCorrelator
│           ├── risk_engine.py       # Layer 5: explainable scoring
│           ├── report.py           # Layer 6: JSON/Markdown evidence reports
│           ├── cache.py             # TTL intelligence cache
│           ├── history.py          # local investigation history
│           ├── orchestrator.py     # the scan pipeline
│           └── cli.py              # `sentiala` command
├── tests/                     # 68 tests + synthetic safe fixtures
├── docs/ARCHITECTURE.md
├── SECURITY.md · CONTRIBUTING.md · CODE_OF_CONDUCT.md · CHANGELOG.md
├── pyproject.toml · .env.example · LICENSE
```

## Roadmap

Built vertically — each phase must actually work before the next begins:

| Phase | Scope | Status |
|---|---|---|
| 1 | Working URL scanner | ✅ done |
| 2 | Risk engine | ✅ done |
| 3 | AI explanation (LLM via `AIProvider`; deterministic correlator shipped) | ✅ partial — local correlator done, cloud provider next |
| 4 | Threat-intelligence adapters (keyed sources via env) | 🔜 next |
| 5 | Public web intelligence | planned |
| 6 | Evidence correlation & graph | partial (correlator) / graph planned |
| 7 | Browser extension (Chrome → Edge → Firefox) | scaffolded |
| 8 | Desktop agent (Windows first) | scaffolded |
| 9 | Security dashboard | scaffolded |
| 10 | Continuous monitoring | planned |
| 11 | Privacy center | planned |
| 12 | Advanced investigations (IP/hash/CVE) | planned |
| 13 | Security hardening & audits | planned |
| 14 | GitHub release | planned |

## Development

```bash
pip install -e ".[dev]"
pytest                       # run the suite (no network needed)
python -m sentiala_core.cli scan https://example.com/
```

Testing philosophy (spec §49–50): every check has unit tests; providers are tested against recorded synthetic responses (reserved `.test` domains only — no real hosts are contacted); false-positive scenarios (legitimate brand login pages, established domains) are first-class test cases; unknown-intelligence and conflicting-intelligence paths are asserted to produce honest `NO RELEVANT PUBLIC INTELLIGENCE FOUND` / degradation output rather than guesses.

## Security & responsible use

- Sentiala performs **read-only lookups against public services**. It never scans, probes, or attacks third-party infrastructure, and it never fetches the URLs it analyzes.
- See [SECURITY.md](SECURITY.md) for the defensive-only scope, what will never be built, and vulnerability reporting.
- Never commit API keys. `.env` is gitignored; `.env.example` documents every planned variable.

## License

MIT — see [LICENSE](LICENSE).
