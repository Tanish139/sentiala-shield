# apps/dashboard — Phase 9 target

Local security command center (web UI): overview, live activity,
investigations, intelligence, evidence graph, privacy center, settings,
and the AI security chat.

**Planned data sources (all local, already produced by the core):**

- `~/.sentiala/history.jsonl` — investigation history + risk deltas
- report JSON files — full evidence for each investigation
- core scan API via the desktop agent's authenticated localhost endpoint

**Two modes planned:** Simple (safe/suspicious/dangerous + what to do)
and Analyst (indicators, sources, correlation, confidence).

**Not implemented yet — deliberately.** The dashboard will be built on
top of a working agent pipeline, never as a static mockup.
