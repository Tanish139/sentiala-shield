# apps/browser-extension — Phase 7 target

Browser protection for Chrome, Edge (Chromium), and Firefox
(MV3/MV2-compatible design).

**Planned responsibilities**

- per-site risk indicator (SAFE / CAUTION / HIGH RISK / CRITICAL)
- right-click context menu: "Scan with Sentiala Shield"
- warning interstitials for HIGH/CRITICAL targets (user can always proceed)
- report-false-positive flow
- **no embedded API keys** — every investigation is delegated over
  native messaging to the Sentiala desktop agent, which hosts the core

**Not implemented yet — deliberately.** This directory is a scaffold so
the architecture is documented; no fake buttons will be added. The
extension ships only when the Phase 8 local agent can serve it end to
end: extension → agent → core → verdict → warning.

Design notes: see `docs/ARCHITECTURE.md`.
