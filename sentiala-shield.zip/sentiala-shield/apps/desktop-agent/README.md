# apps/desktop-agent — Phase 8 target

Local security agent. **Windows first** (then Linux, macOS).

**Planned responsibilities**

- hosts `sentiala_core` (this repository's engine) locally
- native-messaging host for the browser extension
- authenticated localhost API for the dashboard
- scan requests, safe metadata analysis of downloads, notifications,
  threat history, configuration management
- signed, verified updates for itself, rules, and threat intelligence

**Deliberately out of scope, forever:** credential access, keylogging,
cookie theft, covert persistence, monitoring of other people,
remote control. See `../../SECURITY.md`.

**Not implemented yet — deliberately.** Shipping a tray icon with fake
buttons would violate the product standard; the agent lands with real
extension-to-core communication in Phase 8.
